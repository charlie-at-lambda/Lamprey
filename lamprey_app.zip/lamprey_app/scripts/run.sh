#!/usr/bin/env bash
# =============================================================================
# Lamprey development / manual run script
# =============================================================================
# For running Lamprey in a terminal during development or quick demos.
# For a persistent background service use install-service.sh instead.
#
# USAGE:
#   ./scripts/run.sh
#
# OVERRIDE SETTINGS (environment variables take precedence over defaults below):
#   APP_PORT=9000 ./scripts/run.sh
#   APP_HOST=0.0.0.0 APP_SECRET=mysecret ./scripts/run.sh
#
# SOURCE A CONFIG FILE (optional):
#   source ./scripts/lamprey.env && ./scripts/run.sh
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

# Source lamprey.env if it exists and no APP_SECRET is already set.
# This lets developers keep secrets in the env file without exporting manually.
ENV_FILE="$(dirname "$0")/lamprey.env"
if [[ -f "${ENV_FILE}" && -z "${APP_SECRET:-}" ]]; then
    # Only source uncommented, non-empty variable lines to avoid eval'ing comments
    while IFS='=' read -r key value; do
        [[ "${key}" =~ ^[[:space:]]*# ]] && continue
        [[ -z "${key// }" ]] && continue
        export "${key}=${value}"
    done < <(grep -E '^[A-Z_]+=.' "${ENV_FILE}" || true)
fi

export APP_HOST="${APP_HOST:-127.0.0.1}"
export APP_PORT="${APP_PORT:-8080}"
export APP_SECRET="${APP_SECRET:-}"
export DEFAULT_ADMIN_PASSWORD="${DEFAULT_ADMIN_PASSWORD:-admin123!}"
export COOKIE_SECURE="${COOKIE_SECURE:-0}"

mkdir -p data static

echo "Starting Lamprey on http://${APP_HOST}:${APP_PORT}"
echo "Log export HTTP:   ${LOG_EXPORT_URL:-(disabled)}"
echo "Log export syslog: ${LOG_EXPORT_SYSLOG_HOST:-(disabled)}"
echo "Press Ctrl-C to stop."
echo ""

exec python3 app.py
