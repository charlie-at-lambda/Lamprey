#!/usr/bin/env bash
# =============================================================================
# Lamprey service installer
# =============================================================================
# Installs Lamprey as a persistent background service on Linux (systemd) or
# macOS (launchd). The server starts automatically on boot and restarts on crash.
#
# USAGE:
#   sudo ./scripts/install-service.sh          # installs to /opt/lamprey
#   sudo ./scripts/install-service.sh /srv/lamprey  # custom install path
#
# WHAT IT DOES:
#   1. Creates a dedicated 'lamprey' system user (Linux) or uses current user (macOS)
#   2. Copies application files to the install path
#   3. Creates required directories (data/, logs/)
#   4. Installs and enables the service unit
#   5. Starts the service
#
# AFTER INSTALL:
#   - Edit INSTALL_DIR/scripts/lamprey.env to set APP_SECRET, passwords, etc.
#   - Restart the service:  sudo systemctl restart lamprey   (Linux)
#                           sudo launchctl stop/start com.lamprey.server  (macOS)
# =============================================================================
set -euo pipefail

INSTALL_DIR="${1:-/opt/lamprey}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# ── Detect OS ─────────────────────────────────────────────────────────────────
OS="$(uname -s)"
case "${OS}" in
    Linux*)  PLATFORM="linux"  ;;
    Darwin*) PLATFORM="macos"  ;;
    *)
        echo "ERROR: Unsupported platform '${OS}'. Only Linux and macOS are supported."
        exit 1
        ;;
esac

echo "==> Installing Lamprey to ${INSTALL_DIR} on ${PLATFORM}"

# ── Check for required tools ──────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found. Install Python 3.10 or later and retry."
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(sys.version_info.minor)")
if [[ "${PYTHON_VERSION}" -lt 10 ]]; then
    echo "ERROR: Python 3.10+ is required. Found: $(python3 --version)"
    exit 1
fi

# ── Create install directory ──────────────────────────────────────────────────
echo "==> Creating install directory"
mkdir -p "${INSTALL_DIR}/data"
mkdir -p "${INSTALL_DIR}/static"
mkdir -p "${INSTALL_DIR}/scripts"

# ── Copy application files ────────────────────────────────────────────────────
echo "==> Copying application files"
cp "${APP_DIR}/app.py"              "${INSTALL_DIR}/app.py"
cp -r "${APP_DIR}/static/"          "${INSTALL_DIR}/static/"
cp "${SCRIPT_DIR}/lamprey.env"      "${INSTALL_DIR}/scripts/lamprey.env"

# ── Platform-specific service installation ────────────────────────────────────
if [[ "${PLATFORM}" == "linux" ]]; then

    # ── Verify systemd is available ───────────────────────────────────────────
    if ! command -v systemctl &>/dev/null; then
        echo "ERROR: systemctl not found. This installer requires systemd."
        exit 1
    fi

    # ── Create dedicated system user ──────────────────────────────────────────
    echo "==> Creating 'lamprey' system user"
    if ! id -u lamprey &>/dev/null; then
        useradd --system --no-create-home --shell /usr/sbin/nologin \
                --home-dir "${INSTALL_DIR}" lamprey
        echo "    Created user 'lamprey'"
    else
        echo "    User 'lamprey' already exists — skipping"
    fi

    # ── Set ownership ─────────────────────────────────────────────────────────
    echo "==> Setting file ownership"
    chown -R lamprey:lamprey "${INSTALL_DIR}"
    chmod 750 "${INSTALL_DIR}"
    chmod 640 "${INSTALL_DIR}/scripts/lamprey.env"

    # ── Create log directory ──────────────────────────────────────────────────
    mkdir -p /var/log/lamprey
    chown lamprey:lamprey /var/log/lamprey

    # ── Install systemd unit ──────────────────────────────────────────────────
    echo "==> Installing systemd unit"
    # Patch WorkingDirectory in the unit to match the install path
    sed "s|WorkingDirectory=.*|WorkingDirectory=${INSTALL_DIR}|g; \
         s|ExecStart=.*|ExecStart=$(command -v python3) ${INSTALL_DIR}/app.py|g; \
         s|EnvironmentFile=.*|EnvironmentFile=-${INSTALL_DIR}/scripts/lamprey.env|g; \
         s|ReadWritePaths=.*|ReadWritePaths=${INSTALL_DIR}/data /var/log/lamprey|g" \
        "${SCRIPT_DIR}/lamprey.service" \
        > /etc/systemd/system/lamprey.service

    systemctl daemon-reload
    systemctl enable lamprey
    systemctl start lamprey

    echo ""
    echo "======================================================================"
    echo " Lamprey service installed and started on Linux (systemd)"
    echo "======================================================================"
    echo " Status:      sudo systemctl status lamprey"
    echo " Logs:        sudo journalctl -u lamprey -f"
    echo " Restart:     sudo systemctl restart lamprey"
    echo " Stop:        sudo systemctl stop lamprey"
    echo " Config:      ${INSTALL_DIR}/scripts/lamprey.env"
    echo "======================================================================"
    echo " IMPORTANT: Edit lamprey.env to set APP_SECRET and DEFAULT_ADMIN_PASSWORD"
    echo " then run:  sudo systemctl restart lamprey"
    echo "======================================================================"

elif [[ "${PLATFORM}" == "macos" ]]; then

    PLIST_SRC="${SCRIPT_DIR}/com.lamprey.server.plist"
    PLIST_DEST="/Library/LaunchDaemons/com.lamprey.server.plist"

    # ── Create log directory ──────────────────────────────────────────────────
    echo "==> Creating log directory"
    mkdir -p /var/log/lamprey

    # ── Patch plist with correct install path ─────────────────────────────────
    echo "==> Installing launchd plist"
    PYTHON3_PATH="$(command -v python3)"
    sed "s|/opt/lamprey/app.py|${INSTALL_DIR}/app.py|g; \
         s|<string>/opt/lamprey</string>|<string>${INSTALL_DIR}</string>|g; \
         s|<string>/usr/bin/python3</string>|<string>${PYTHON3_PATH}</string>|g" \
        "${PLIST_SRC}" > "${PLIST_DEST}"

    chown root:wheel "${PLIST_DEST}"
    chmod 644 "${PLIST_DEST}"

    # ── Load the service ──────────────────────────────────────────────────────
    launchctl load -w "${PLIST_DEST}" || true

    echo ""
    echo "======================================================================"
    echo " Lamprey service installed and started on macOS (launchd)"
    echo "======================================================================"
    echo " Status:   sudo launchctl list | grep lamprey"
    echo " Logs:     tail -f /var/log/lamprey/lamprey.log"
    echo " Errors:   tail -f /var/log/lamprey/lamprey.err"
    echo " Restart:  sudo launchctl stop com.lamprey.server"
    echo "           sudo launchctl start com.lamprey.server"
    echo " Config:   ${INSTALL_DIR}/scripts/lamprey.env"
    echo " NOTE: For macOS, update EnvironmentVariables in the plist directly or"
    echo "       use a wrapper launch script that sources lamprey.env"
    echo "======================================================================"
    echo " IMPORTANT: Edit lamprey.env (and plist EnvironmentVariables) to set"
    echo " APP_SECRET and DEFAULT_ADMIN_PASSWORD before exposing to users."
    echo "======================================================================"

fi
