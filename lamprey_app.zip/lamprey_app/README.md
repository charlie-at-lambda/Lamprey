# Lamprey — Customer Operations Workspace

Lamprey is currently a demo of a self-contained, zero-dependency customer operations platform. It combines a hybrid CMDB and ticketing system into a single deployable Python file, purpose-built for data center and managed-services teams that need a clean, professional internal tool without standing up a full SaaS stack.

**Lamprey is an intranet-only application.** It is designed to be deployed exclusively within a secure internal network and accessed by staff only. External customers do not connect to Lamprey directly. The intended workflow for inbound customer requests is: customers email a support address (e.g. `support@yourorg.com`), that email is received by staff and converted into a ticket manually or via an inbound email integration. Staff communicate back to customers by posting customer-visible ticket notes, which trigger outbound email notifications to the authorised contacts on record.

---

## Overview & Technical Capabilities

Lamprey is designed to run entirely from the Python standard library — no pip installs, no Docker image, no external services required. Drop it on any machine with Python 3.10+ and it runs.

### Core feature set

- **Customer CMDB** — structured customer records with company info, region, type, status, address, contacts, and technician notes. Full audit trail on every change.
- **Ticketing system** — create, assign, prioritize, and resolve support tickets linked to customer organizations. Status lifecycle: Open → In Progress → Resolved → Closed.
- **Ticket notes thread** — threaded comments with internal vs. customer-visible visibility control. Customer-visible notes trigger outbound email notifications to authorised contacts on record.
- **Customer contacts** — named individuals within a customer organisation stored as authorisation references. Contacts confirm who is permitted to make requests on behalf of their org. Email addresses receive outbound staff notifications. Contacts do not have Lamprey logins.
- **Inbound request workflow** — external customers email a support address. Staff receive the email, open a ticket in Lamprey, and communicate back via customer-visible notes. No external-facing login surface exists.
- **Role-based access control** — three staff roles with enforced server-side hierarchy: `admin` → `engineer` → `technician`. Each role has a clearly defined permission boundary.
- **External data integration scaffold** — stub hooks for Zendesk, Jira, PagerDuty, Slack, Artifactory, and a generic webhook. External data is treated as authoritative and overwrites local records through a single guarded write path.
- **Web scraper / enrichment** — paste a public URL on any customer record to automatically pull in a source summary. SSRF protection blocks private/loopback targets by default.
- **Online staff count** — the dashboard shows engineers and technicians currently active, derived from live session data. Clicking opens a searchable staff list.
- **Department tagging** — engineers and technicians can be assigned to one of seven defined departments with a clearly marked extension point for adding more.
- **User management** — admins can create, edit, and delete any account. Engineers can add technician accounts only. Deletion preserves the full audit history.
- **Full audit trail** — every create, update, delete, enrich, and sync action is logged with actor, timestamp, and a change summary.

### Security baseline

- PBKDF2-HMAC-SHA256 password hashing with per-user salt
- Server-side session storage in SQLite with idle and absolute TTL
- CSRF tokens on all state-changing forms
- Origin and Referer validation on every POST
- Login throttling with configurable lockout window
- `HttpOnly`, `SameSite=Lax` cookies; optional `Secure` flag for TLS
- Request body size cap
- Parameterized queries throughout — no raw string interpolation into SQL
- Input length normalization on all form fields
- HTML output escaping on all user-supplied data

### Architecture

Lamprey is a single Python file (`app.py`) served by Python's built-in `ThreadingHTTPServer`. There is no framework, no ORM, and no template engine. HTML is generated directly in Python f-strings. The database is SQLite running in WAL mode. Schema migrations are applied automatically at startup via `PRAGMA table_info` checks so the database evolves without a migration tool.

---

## Languages

| Language | Role |
|----------|------|
| **Python 3** | Entire application server, routing, business logic, HTML generation, database access, session management, email notification stub |
| **SQL (SQLite dialect)** | Schema definition, migrations, all data queries and writes |
| **HTML** | Page structure, rendered server-side via Python f-strings |
| **CSS** | Full custom stylesheet (`static/style.css`) — layout, theming, badge system, animations |
| **Bash / Zsh** | Launch script (`scripts/run.sh`), environment configuration |

---

## FAQ

**Q1. Does Lamprey require any third-party packages?**
No. The entire application runs on the Python standard library. There is nothing to install beyond Python 3.10 or later. Start it with `./scripts/run.sh` and it is ready.

**Q2. What database does Lamprey use and where is it stored?**
Lamprey uses SQLite, stored at `data/app.db` relative to the working directory. The database is created automatically on first run. WAL mode is enabled for better concurrent read performance.

**Q3. How are schema changes handled when I upgrade Lamprey?**
Migrations run automatically at startup. On each launch, `init_db()` checks the existing column set with `PRAGMA table_info` and issues `ALTER TABLE` statements only for columns that are missing. You never need to run a migration command manually.

**Q4. What are the three user roles and what can each one do?**
- `admin` — full access: manage all users, customers, tickets, and delete any record.
- `engineer` — can create/edit customers and tickets, add technician accounts, manage contacts. Cannot delete users or customers.
- `technician` — can view and work tickets and customer records. Cannot manage users.

There is no external-facing customer login. Lamprey is a staff-only intranet tool.

**Q5. How do external customers submit requests if they can't log in?**
External customers email a support address (e.g. `support@yourorg.com`). Staff receive the email, create a ticket in Lamprey on the customer's behalf, and communicate back by posting notes marked "Customer visible." Those notes trigger outbound email notifications to all authorised contacts on record for that customer organisation. This keeps the entire interaction inside the secure intranet — no external-facing login surface exists.

**Q6. How does external data integration work, and does it overwrite local data?**
Yes, intentionally. External data is treated as the authoritative source of truth. Any customer or ticket data imported through the integration scaffold is written through `apply_external_customer_update()` and `upsert_external_ticket()`, which overwrite matching local fields rather than filling blanks. A whitelist (`EXTERNAL_CUSTOMER_WRITABLE_FIELDS`) prevents external payloads from touching internal-only columns.

**Q7. How do customer contacts receive email notifications?**
When a staff member posts a ticket note and checks "Customer visible", Lamprey calls `notify_customer_contacts()`, which queries all contacts for the linked customer organisation that have an email address on file and sends a notification via SMTP. This is the primary outbound communication channel — staff post an update, the contact receives it by email. Configure `EMAIL_SMTP_HOST`, `EMAIL_SENDER`, and `EMAIL_PASSWORD` as environment variables to activate it. If those variables are not set the notification is skipped silently and an audit entry is written instead. Contacts do not log in to Lamprey; they receive only the emails staff choose to send them.

**Q8. What happens to audit logs when a user or customer is deleted?**
Audit log rows are never deleted. When an account is removed, the `users` row is dropped but all `audit_log` rows that reference that username remain intact. When a customer is deleted, the cascade removes their tickets and notes, but the audit trail entries for that customer's history are preserved. This ensures a permanent record of who did what, even after accounts or organizations are gone.

**Q9. Is Lamprey intended to be exposed to the internet?**
No. Lamprey is an intranet-only tool and should never be placed on a public network. It is designed to run inside a secure internal network, accessible to staff only. For intranet hardening: place it behind an internal reverse proxy with TLS, replace the default admin password via `DEFAULT_ADMIN_PASSWORD`, set a strong `APP_SECRET`, and set `COOKIE_SECURE=1`. A full production hardening checklist is in the "Remaining gaps" section below.

**Q10. How do I add a new department or expand the integration stubs?**
Departments are defined in the `DEPARTMENTS` list constant near the top of `app.py`. Add a new string to that list and it immediately appears in the department dropdown for user forms — no other changes needed. Integration stubs (Zendesk, Jira, PagerDuty, Slack, Artifactory, Generic Webhook) are in the clearly marked `FUTURE API INTEGRATION SCAFFOLD` block. Each stub is commented out with a note describing which feature it supports and what to fill in to activate it.

---

## Production-style security controls

- Server-side session storage in the local app DB
- Session idle timeout and absolute expiration
- CSRF tokens on all state-changing forms
- Origin and Referer validation on POST requests
- Login throttling / temporary lockout on repeated failures
- Stricter security headers on all pages
- Cookie hardening with `HttpOnly` and `SameSite=Lax`
- Optional `Secure` cookies for TLS deployments
- Request body size limits
- Input length normalization on customer fields
- SSRF protection for the scraper blocking private and loopback targets by default
- SQLite WAL mode and cleanup of expired session / throttle state

## Demo credentials

- Username: `demodude`
- Password: `$$DEMO$$demo`

Change these before using beyond a demo.

## Run it

```bash
cd lamprey_app
./scripts/run.sh
```

Open:

```text
http://127.0.0.1:8080
```

## Recommended hardened demo run

```bash
export APP_SECRET="replace-with-a-long-random-secret"
export DEFAULT_ADMIN_PASSWORD="replace-this-demo-password"
./scripts/run.sh
```

## Environment variables

- `APP_HOST` default: `127.0.0.1`
- `APP_PORT` default: `8080`
- `APP_SECRET` default: derived demo fallback if unset
- `DEFAULT_ADMIN_PASSWORD` default: `admin123!`
- `COOKIE_SECURE` default: `0` (`1` when behind HTTPS/TLS)
- `ALLOW_PRIVATE_SCRAPE` default: `0`
- `SESSION_TTL_SECONDS` default: `43200`
- `SESSION_IDLE_SECONDS` default: `3600`
- `MAX_BODY_BYTES` default: `32768`
- `LOGIN_MAX_FAILURES` default: `5`
- `LOGIN_WINDOW_SECONDS` default: `900`
- `LOGIN_LOCK_SECONDS` default: `900`

## Scraper policy

By default, the demo scraper only allows `http` and `https` targets that resolve to non-private, non-loopback addresses. This is intended to reduce SSRF risk while still allowing public-site enrichment for demos.

If you deliberately need to scrape internal targets for a lab/demo:

```bash
export ALLOW_PRIVATE_SCRAPE=1
```

Only do that in a controlled environment.

## Remaining gaps before a real production deployment

This version is a compact secure demo, There are architectural changes that would likely need to be made on a case by case basis to meet the prerequisites and security mandates of individual organizations before production use. Changes I would definitely add if I intended to make a production version are:

- Consider more robust architecture and frameworks, make use of GoLang for building UI components
- Connect External sources to pull and aggregate customer data (artifactory objects, API queries, etc.)
- TLS termination at a reverse proxy
- a real RDBMS such as PostgreSQL for concurrent multi-user durability
- password rotation and reset workflows
- role-based authorization beyond the single stored role field
- structured application logging
- separate worker/service boundaries for scraping/import activity
- backup and restore automation
- external secret management

## Demo workflow

1. Start with an empty customer table.
2. Log in as `admin`.
3. Click **Users** to create a demo technician account, or go directly to **Add Customer**.
4. Save a customer with only a company name, or even mostly blank fields.
5. Re-open the record and optionally enrich it with a public company URL.
6. Show the populated source summary and audit log.

## Included assets

- `static/style.css` for the branded professional UI
- `static/logo.svg` for the Lamprey header logo
- updated session and CSRF cookie names using the Lamprey product prefix
