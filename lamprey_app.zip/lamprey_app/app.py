#!/usr/bin/env python3
# =============================================================================
# LAMPREY — Customer Operations Workspace
# =============================================================================
# Single-file Python web application. No third-party dependencies required.
# Uses only the Python standard library (sqlite3, http.server, hashlib, etc.)
#
# HOW TO RUN (development):
#   python3 app.py            (listens on 127.0.0.1:8080 by default)
#   APP_PORT=9000 python3 app.py
#
# HOW TO RUN AS A SERVICE:
#   Linux (systemd):  see scripts/lamprey.service  — install with scripts/install-service.sh
#   macOS (launchd):  see scripts/com.lamprey.server.plist
#   Both methods use scripts/lamprey.env for environment variable configuration.
#
# KEY CONFIGURATION POINTS (see the CONFIG BLOCK section below):
#   - APP_SECRET          : set before production to a long random string
#   - DEFAULT_ADMIN_PASSWORD : change to remove the demo banner
#   - ZENDESK_* / ARTIFACTORY_* : set to enable live external integrations
#   - LOG_EXPORT_URL      : set to ship audit logs to an external log server
#
# FILE STRUCTURE (top to bottom):
#   1.  Imports
#   2.  Config block (env vars, tunable constants)
#   3.  Database helpers (init_db, session, cleanup)
#   4.  Security helpers (passwords, CSRF, scraper)
#   5.  Integration stubs (ZenDesk, Artifactory, future APIs)
#   6.  Log exporter (background thread, ships audit_log to external server)
#   7.  HTML rendering helpers (render_page, badges, nav)
#   8.  AppHandler class — HTTP request handler
#       a. do_GET  — URL router for all GET requests
#       b. do_POST — URL router for all POST requests
#       c. Page methods (dashboard, customers, tickets, users, audit, ...)
#   9.  Server entry point (main function, signal handling, service-safe startup)
# =============================================================================

# ── IMPORTS ───────────────────────────────────────────────────────────────────
# All stdlib — no pip install needed.
# If you add a third-party package (e.g. requests, jinja2) install it with:
#   uv pip install <package>   (per Wu-Ta-Gentic Python tooling guardrail)
import hashlib
import hmac
import html
import ipaddress
import json
import logging
import os
import re
import secrets
import signal
import socket
import sqlite3
import threading
import time
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
# ── END IMPORTS ───────────────────────────────────────────────────────────────

# ── LOGGING SETUP ─────────────────────────────────────────────────────────────
# Structured logging to stdout — compatible with systemd journal, Docker logs,
# and any log collector that reads stdout/stderr (Fluentd, Vector, etc.)
# The format is designed to be easy to parse and grep for specific events.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%SZ",
)
log = logging.getLogger("lamprey")
# ── END LOGGING SETUP ─────────────────────────────────────────────────────────

# ── CONFIG BLOCK ──────────────────────────────────────────────────────────────
# All tunable values are read from environment variables with safe defaults.
# Override any of these by exporting the variable before starting the server,
# or by placing them in scripts/lamprey.env (used by the systemd / launchd service).
#
# ── Paths (usually no need to change) ─────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "app.db"               # SQLite database file location
STATIC_DIR = BASE_DIR / "static"                     # CSS, SVG assets directory
LOG_EXPORT_WATERMARK_FILE = BASE_DIR / "data" / "log_export_watermark"  # tracks last exported audit_log id

# ── Network ────────────────────────────────────────────────────────────────────
HOST = os.environ.get("APP_HOST", "127.0.0.1")   # Change to "0.0.0.0" to listen on all interfaces
PORT = int(os.environ.get("APP_PORT", "8080"))

# ── Security ───────────────────────────────────────────────────────────────────
# APP_SECRET: used to derive a fallback secret when env var is absent.
# Set this to a long random string in any real deployment:
#   export APP_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
APP_SECRET = os.environ.get("APP_SECRET", "")

# ── Session / Cookie names ─────────────────────────────────────────────────────
# Change these if you need to run multiple Lamprey instances on the same domain.
SESSION_NAME = os.environ.get("SESSION_NAME", "lamprey_session")
CSRF_NAME = os.environ.get("CSRF_COOKIE_NAME", "lamprey_csrf")

# ── Session lifetime ───────────────────────────────────────────────────────────
# TTL  = absolute session expiry from login (default 12 hours)
# IDLE = session expires if no requests made within this window (default 1 hour)
SESSION_TTL_SECONDS = int(os.environ.get("SESSION_TTL_SECONDS", str(60 * 60 * 12)))
SESSION_IDLE_SECONDS = int(os.environ.get("SESSION_IDLE_SECONDS", str(60 * 60)))

# ── Request limits ─────────────────────────────────────────────────────────────
MAX_BODY_BYTES = int(os.environ.get("MAX_BODY_BYTES", "32768"))   # Max POST body size (32 KB)

# ── Cookie security ────────────────────────────────────────────────────────────
# Set COOKIE_SECURE=1 when serving over HTTPS (adds the Secure flag to cookies)
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "0") == "1"

# ── Web scraper policy ─────────────────────────────────────────────────────────
# ALLOW_PRIVATE_SCRAPE=1 permits scraping private/loopback IPs (dev only, not for prod)
ALLOW_PRIVATE_SCRAPE = os.environ.get("ALLOW_PRIVATE_SCRAPE", "0") == "1"

# ── Login rate limiting ────────────────────────────────────────────────────────
# LOGIN_WINDOW_SECONDS : sliding window in which failures are counted (default 15 min)
# LOGIN_MAX_FAILURES   : number of failures before lockout (default 5)
# LOGIN_LOCK_SECONDS   : how long the lockout lasts (default 15 min)
LOGIN_WINDOW_SECONDS = int(os.environ.get("LOGIN_WINDOW_SECONDS", "900"))
LOGIN_MAX_FAILURES = int(os.environ.get("LOGIN_MAX_FAILURES", "5"))
LOGIN_LOCK_SECONDS = int(os.environ.get("LOGIN_LOCK_SECONDS", "900"))

# ── Default admin credentials ──────────────────────────────────────────────────
# The admin account is seeded once when the database is first created.
# Change DEFAULT_ADMIN_PASSWORD to remove the demo-mode banner.
#   export DEFAULT_ADMIN_PASSWORD="YourNewSecurePassword"
DEFAULT_ADMIN_PASSWORD = os.environ.get("DEFAULT_ADMIN_PASSWORD", "admin123!")
# ── END CONFIG BLOCK ───────────────────────────────────────────────────────────

# ── DEMO MODE BANNER ──────────────────────────────────────────────────────────
# This is the message shown in the warning banner at the top of the dashboard
# when the app is running in demo mode (default admin password unchanged).
# To update the banner text, change the string below or set the
# DEMO_WARNING_MESSAGE environment variable before starting the server.
DEMO_WARNING_MESSAGE = os.environ.get(
    "DEMO_WARNING_MESSAGE",
    "Lamprey is currently in demo mode and is not ready for production"
)
# ── END DEMO MODE BANNER ──────────────────────────────────────────────────────

# ── INTEGRATION CONFIG ────────────────────────────────────────────────────────
# External ticketing system credentials. When not set the app runs in demo
# mode — internal tickets still work, external sync is gracefully disabled.
#
# ZenDesk — set all three vars to enable live ticket sync:
ZENDESK_SUBDOMAIN = os.environ.get("ZENDESK_SUBDOMAIN", "")    # e.g. yourcompany
ZENDESK_EMAIL     = os.environ.get("ZENDESK_EMAIL", "")         # agent login email
ZENDESK_API_TOKEN = os.environ.get("ZENDESK_API_TOKEN", "")     # API token
#
# Artifactory — set both vars to enable live issue sync:
ARTIFACTORY_URL   = os.environ.get("ARTIFACTORY_URL", "")       # base URL
ARTIFACTORY_TOKEN = os.environ.get("ARTIFACTORY_API_TOKEN", "") # access token
#
# Email notifications — set all four vars to enable outbound email to customer contacts.
# Used when a customer-visible ticket note is posted. Without these, email is logged only.
EMAIL_SMTP_HOST   = os.environ.get("EMAIL_SMTP_HOST", "")       # e.g. smtp.example.com
EMAIL_SMTP_PORT   = int(os.environ.get("EMAIL_SMTP_PORT", "587"))
EMAIL_SENDER      = os.environ.get("EMAIL_SENDER", "")          # From: address
EMAIL_PASSWORD    = os.environ.get("EMAIL_PASSWORD", "")        # SMTP auth password
#
# ── LOG EXPORT ──────────────────────────────────────────────────────────────
# Ships audit_log rows to an external log server so history is retained beyond
# the local 90-day purge window. Rows are exported in order, using a watermark
# file (data/log_export_watermark) to track the last successfully shipped ID.
#
# HTTP/HTTPS endpoint (Elasticsearch, Splunk HEC, Loki, generic webhook, etc.)
#   LOG_EXPORT_URL      — full URL to POST batches to (empty = HTTP export disabled)
#   LOG_EXPORT_API_KEY  — value sent as "Authorization: Bearer <key>" header
#   LOG_EXPORT_FORMAT   — "ndjson" (one JSON obj per line, default) or "json_array"
#
# Syslog (UDP or TCP — Graylog, rsyslog, any RFC-5424-compatible receiver)
#   LOG_EXPORT_SYSLOG_HOST  — syslog server hostname/IP (empty = syslog disabled)
#   LOG_EXPORT_SYSLOG_PORT  — default 514
#   LOG_EXPORT_SYSLOG_PROTO — "udp" (default) or "tcp"
#
# Tuning
#   LOG_EXPORT_INTERVAL_SECONDS — how often to check for new rows (default 60)
#   LOG_EXPORT_BATCH_SIZE       — rows per HTTP POST / syslog flush (default 500)
LOG_EXPORT_URL              = os.environ.get("LOG_EXPORT_URL", "")
LOG_EXPORT_API_KEY          = os.environ.get("LOG_EXPORT_API_KEY", "")
LOG_EXPORT_FORMAT           = os.environ.get("LOG_EXPORT_FORMAT", "ndjson")
LOG_EXPORT_SYSLOG_HOST      = os.environ.get("LOG_EXPORT_SYSLOG_HOST", "")
LOG_EXPORT_SYSLOG_PORT      = int(os.environ.get("LOG_EXPORT_SYSLOG_PORT", "514"))
LOG_EXPORT_SYSLOG_PROTO     = os.environ.get("LOG_EXPORT_SYSLOG_PROTO", "udp").lower()
LOG_EXPORT_INTERVAL_SECONDS = int(os.environ.get("LOG_EXPORT_INTERVAL_SECONDS", "60"))
LOG_EXPORT_BATCH_SIZE       = int(os.environ.get("LOG_EXPORT_BATCH_SIZE", "500"))
# ── END INTEGRATION CONFIG ────────────────────────────────────────────────────

# ── DEPARTMENT DEFINITIONS ─────────────────────────────────────────────────────
# Departments are assigned to engineer and technician accounts to indicate which
# team they belong to. Admins are not required to select a department.
#
# The DEPARTMENTS list below drives the dropdown in the user form and the
# validation in save_user(). No database migration is needed when adding
# new entries — department is stored as free text in the users table.
#
# TO ADD A NEW DEPARTMENT:
#   1. Append the department name string inside the list below.
#   2. Restart the server — the new option appears in the user form automatically.
#   3. Existing users whose department is not in this list are still valid;
#      their stored value will display as-is on their profile.
#
# TO RENAME A DEPARTMENT:
#   1. Update the string in this list.
#   2. If you want existing user records updated, run a one-time SQL command:
#      UPDATE users SET department='New Name' WHERE department='Old Name';
DEPARTMENTS = [
    "DC Operations",
    "Support-Response",
    "Networking",
    "HPC Support Engineering",
    "RMA Operations",
    "Legal",
    "Executive Leadership",
    # ── ADD NEW DEPARTMENTS HERE ──────────────────────────────────────────────
    # Append additional department name strings on new lines, e.g.:
    # "Field Engineering",
    # "Security Operations",
    # "DevOps",
    # "Quality Assurance",
    # "Product Management",
    # ── END ADD NEW DEPARTMENTS ───────────────────────────────────────────────
]
# ── END DEPARTMENT DEFINITIONS ─────────────────────────────────────────────────

# Derive a deterministic fallback secret from the install path when APP_SECRET
# is not set. This is safe for demo use but must be replaced in production.
if not APP_SECRET:
    seed = f"{BASE_DIR}:{HOST}:{PORT}".encode()
    APP_SECRET = hashlib.sha256(seed).hexdigest()


# ── DATABASE HELPERS ──────────────────────────────────────────────────────────
# db_conn()  — opens a connection with sensible pragma defaults.
#              WAL mode allows concurrent reads; busy_timeout avoids lock errors.
#              Always call conn.close() or use in a with-statement after use.
def now_ts() -> int:
    """Returns the current UTC time as a Unix integer timestamp."""
    return int(time.time())


def db_conn():
    """Open and return a configured SQLite connection. Close after use."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row     # rows accessible as dicts: row["column"]
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


# ── PASSWORD HASHING ──────────────────────────────────────────────────────────
# Uses PBKDF2-HMAC-SHA256 with 300,000 iterations — NIST-recommended minimum.
# hash_password()   → returns (salt_hex, hash_hex)  — store both in the DB
# verify_password() → constant-time comparison to prevent timing attacks
# To change the iteration count, update the 300000 literal in both functions.
def hash_password(password: str):
    """Hash a plain-text password. Returns (salt, hash) both as hex strings."""
    salt = secrets.token_hex(16)
    pwd_hash = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 300000).hex()
    return salt, pwd_hash


def verify_password(password: str, salt: str, stored_hash: str):
    """Verify a plain-text password against a stored (salt, hash) pair."""
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 300000).hex()
    return hmac.compare_digest(candidate, stored_hash)


def user_agent_hash(user_agent: str) -> str:
    """One-way hash of the User-Agent string used for session binding."""
    return hashlib.sha256((user_agent or "").encode()).hexdigest()
# ── END DATABASE / PASSWORD HELPERS ───────────────────────────────────────────


# ── DATABASE SCHEMA & INITIALIZATION ──────────────────────────────────────────
# init_db() is called once at startup.
#
# TABLES:
#   users        — local Lamprey accounts (username, role, hashed password)
#   customers    — customer/company records (the core CMDB entity)
#   tickets      — support tickets linked to customers
#   ticket_notes — threaded comments on tickets
#   audit_log    — append-only log of every user action (retained 90 days)
#   sessions     — server-side session store (cleaned up on each request)
#   login_failures — rate-limiting table for brute-force protection
#
# ADDING A NEW COLUMN:
#   1. Add it to the CREATE TABLE statement (runs on first install).
#   2. Add an ALTER TABLE migration below the executescript() call so that
#      existing databases are upgraded automatically.
#   Pattern example:
#       cols = {r[1] for r in cur.execute("PRAGMA table_info(my_table)")}
#       if "new_column" not in cols:
#           cur.execute("ALTER TABLE my_table ADD COLUMN new_column TEXT")
#
# ADDING A NEW TABLE:
#   Add a CREATE TABLE IF NOT EXISTS block inside the executescript() string.
#   No migration needed — IF NOT EXISTS makes it safe to run on existing DBs.
def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = db_conn()
    cur = conn.cursor()
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            display_name TEXT NOT NULL,
            password_salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'technician',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_name TEXT,
            status TEXT,
            primary_contact TEXT,
            email TEXT,
            phone TEXT,
            website TEXT,
            notes TEXT,
            address TEXT,
            source_summary TEXT,
            source_url TEXT,
            created_by TEXT,
            updated_by TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            customer_id INTEGER,
            details TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        );

        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT UNIQUE NOT NULL,
            username TEXT NOT NULL,
            csrf_token TEXT NOT NULL,
            created_ts INTEGER NOT NULL,
            last_seen_ts INTEGER NOT NULL,
            expires_ts INTEGER NOT NULL,
            user_agent_hash TEXT,
            remote_addr TEXT,
            FOREIGN KEY(username) REFERENCES users(username)
        );

        CREATE TABLE IF NOT EXISTS login_failures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            remote_addr TEXT NOT NULL,
            attempted_ts INTEGER NOT NULL,
            success INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT NOT NULL DEFAULT 'Open',
            priority TEXT NOT NULL DEFAULT 'Medium',
            source TEXT NOT NULL DEFAULT 'manual',
            external_id TEXT,
            assigned_to TEXT,
            created_by TEXT NOT NULL,
            updated_by TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        );

        CREATE TABLE IF NOT EXISTS ticket_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER NOT NULL,
            author TEXT NOT NULL,
            body TEXT NOT NULL,
            -- visibility: 'internal' = staff only | 'customer' = visible to customer contacts
            visibility TEXT NOT NULL DEFAULT 'internal',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(ticket_id) REFERENCES tickets(id)
        );

        -- Stores named contacts within a customer organisation.
        -- These are authorisation references only — contacts do not have Lamprey logins.
        -- Email addresses are kept for outbound notifications when staff post customer-visible notes.
        -- Engineers and admins manage contacts via the customer detail page.
        CREATE TABLE IF NOT EXISTS customer_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            title TEXT,
            notes TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        );

        CREATE INDEX IF NOT EXISTS idx_sessions_session_id ON sessions(session_id);
        CREATE INDEX IF NOT EXISTS idx_login_failures_actor ON login_failures(username, remote_addr, attempted_ts);
        CREATE INDEX IF NOT EXISTS idx_customers_updated_at ON customers(updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_tickets_customer_id ON tickets(customer_id);
        CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
        CREATE INDEX IF NOT EXISTS idx_ticket_notes_ticket_id ON ticket_notes(ticket_id);
        CREATE INDEX IF NOT EXISTS idx_audit_log_actor ON audit_log(actor, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_customer_contacts_customer_id ON customer_contacts(customer_id);
        CREATE INDEX IF NOT EXISTS idx_customer_contacts_email ON customer_contacts(email);
        """
    )
    existing_cols = {row[1] for row in cur.execute("PRAGMA table_info(users)")}
    if "is_active" not in existing_cols:
        cur.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
    if "updated_at" not in existing_cols:
        cur.execute("ALTER TABLE users ADD COLUMN updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP")
    audit_cols = {row[1] for row in cur.execute("PRAGMA table_info(audit_log)")}
    if "ticket_id" not in audit_cols:
        cur.execute("ALTER TABLE audit_log ADD COLUMN ticket_id INTEGER")
    cust_cols = {row[1] for row in cur.execute("PRAGMA table_info(customers)")}
    if "region" not in cust_cols:
        cur.execute("ALTER TABLE customers ADD COLUMN region TEXT")
    if "customer_type" not in cust_cols:
        cur.execute("ALTER TABLE customers ADD COLUMN customer_type TEXT")
    # Add department column to users — safe to run on existing databases
    if "department" not in existing_cols:
        cur.execute("ALTER TABLE users ADD COLUMN department TEXT")
    # Add visibility to ticket_notes — 'internal' (staff only) or 'customer' (contacts see it)
    tnote_cols = {row[1] for row in cur.execute("PRAGMA table_info(ticket_notes)")}
    if "visibility" not in tnote_cols:
        cur.execute("ALTER TABLE ticket_notes ADD COLUMN visibility TEXT NOT NULL DEFAULT 'internal'")
    # Add external-sync tracking columns to customers.
    # last_synced_at — ISO timestamp of the most recent successful external sync
    # sync_source    — which system last wrote authoritative data (e.g. 'zendesk')
    if "last_synced_at" not in cust_cols:
        cur.execute("ALTER TABLE customers ADD COLUMN last_synced_at TEXT")
    if "sync_source" not in cust_cols:
        cur.execute("ALTER TABLE customers ADD COLUMN sync_source TEXT")
    cur.execute("SELECT COUNT(*) AS c FROM users")
    if cur.fetchone()["c"] == 0:
        salt, pwd_hash = hash_password(DEFAULT_ADMIN_PASSWORD)
        cur.execute(
            "INSERT INTO users (username, display_name, password_salt, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?, 1)",
            ("admin", "Demo Administrator", salt, pwd_hash, "admin"),
        )
    conn.commit()
    conn.close()


# ── AUDIT LOG RETENTION ────────────────────────────────────────────────────────
# Audit entries older than this are deleted during cleanup_db_state().
# To change retention: adjust the multiplier (currently 90 days).
AUDIT_RETENTION_SECONDS = 90 * 24 * 60 * 60  # 3 months


# ── DB CLEANUP ─────────────────────────────────────────────────────────────────
# cleanup_db_state() is called on every authenticated request (lightweight).
# It expires sessions, trims old login-failure rows, and purges aged audit logs.
# This keeps the DB lean without needing a separate cron job.
def cleanup_db_state(conn: sqlite3.Connection):
    ts = now_ts()
    conn.execute("DELETE FROM sessions WHERE expires_ts < ? OR last_seen_ts < ?", (ts, ts - SESSION_IDLE_SECONDS))
    conn.execute("DELETE FROM login_failures WHERE attempted_ts < ?", (ts - (LOGIN_WINDOW_SECONDS * 4),))
    # Purge audit log entries older than AUDIT_RETENTION_SECONDS (default 90 days)
    cutoff_dt = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts - AUDIT_RETENTION_SECONDS))
    conn.execute("DELETE FROM audit_log WHERE created_at < ?", (cutoff_dt,))
    conn.commit()


# ── SESSION MANAGEMENT ─────────────────────────────────────────────────────────
# Sessions are stored server-side in the sessions table (not in cookies).
# The cookie holds only an opaque random token — no user data is in the cookie.
# make_session() — creates a new session row and returns (session_id, csrf_token)
# read_session()  — validates the token, checks expiry + UA binding, returns dict
# destroy_session() — deletes the session row on logout
def make_session(conn: sqlite3.Connection, username: str, remote_addr: str, ua: str):
    session_id = secrets.token_urlsafe(32)
    csrf_token = secrets.token_urlsafe(24)
    ts = now_ts()
    conn.execute(
        "INSERT INTO sessions (session_id, username, csrf_token, created_ts, last_seen_ts, expires_ts, user_agent_hash, remote_addr) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (session_id, username, csrf_token, ts, ts, ts + SESSION_TTL_SECONDS, user_agent_hash(ua), remote_addr),
    )
    conn.commit()
    return session_id, csrf_token


def read_session(conn: sqlite3.Connection, session_id: str, ua: str):
    row = conn.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
    if not row:
        return None
    ts = now_ts()
    if row["expires_ts"] < ts or row["last_seen_ts"] < ts - SESSION_IDLE_SECONDS:
        conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        conn.commit()
        return None
    expected_ua_hash = row["user_agent_hash"] or ""
    if expected_ua_hash and not hmac.compare_digest(expected_ua_hash, user_agent_hash(ua)):
        conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        conn.commit()
        return None
    user = conn.execute("SELECT username, display_name, role, is_active, customer_id FROM users WHERE username = ?", (row["username"],)).fetchone()
    if not user or int(user["is_active"] or 0) != 1:
        conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        conn.commit()
        return None
    conn.execute("UPDATE sessions SET last_seen_ts = ? WHERE session_id = ?", (ts, session_id))
    conn.commit()
    return {
        "username": user["username"],
        "display_name": user["display_name"],
        "role": user["role"],
        "csrf_token": row["csrf_token"],
        "session_id": row["session_id"],
    }


def destroy_session(conn: sqlite3.Connection, session_id: str):
    conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
    conn.commit()


# ── INPUT HELPERS ──────────────────────────────────────────────────────────────
# normalize_text() — strips whitespace and enforces a character limit on any
# user-supplied string. Always pass form values through this before storing.
# To add a new field: call normalize_text(form.get("field_name", ""), MAX_LEN)
def normalize_text(value: str, max_len: int) -> str:
    value = (value or "").strip()
    return value[:max_len] if len(value) > max_len else value


# ── ORIGIN / REFERER VALIDATION ────────────────────────────────────────────────
# Used inside require_csrf() to verify requests originate from the same host.
# Returns True (allow) when no Origin/Referer header is present (non-browser).
def safe_same_origin(origin_or_referer: str, host: str) -> bool:
    if not origin_or_referer:
        return True
    try:
        return urllib.parse.urlparse(origin_or_referer).netloc == host
    except Exception:
        return False


# ── SCRAPER IP ALLOW-LIST ──────────────────────────────────────────────────────
# is_ip_allowed() blocks scrape requests to private/loopback ranges by default
# to prevent SSRF (server-side request forgery) attacks.
# Set ALLOW_PRIVATE_SCRAPE=1 only in isolated development environments.
def is_ip_allowed(ip_text: str) -> bool:
    ip = ipaddress.ip_address(ip_text)
    if ALLOW_PRIVATE_SCRAPE:
        return True
    return not any([ip.is_private, ip.is_loopback, ip.is_link_local, ip.is_multicast, ip.is_reserved, ip.is_unspecified])


# ── HTML SCRAPER ───────────────────────────────────────────────────────────────
# SimpleHTMLScraper extracts title, meta description, H1 headings, emails, and
# phone numbers from a public HTML page for the "Source Enrichment" feature.
# To capture additional fields, add a new handle_starttag or handle_data branch.
# scrape_source(url) orchestrates the full fetch → parse → return dict pipeline.
class SimpleHTMLScraper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.title = ""
        self.in_title = False
        self.meta_description = ""
        self.h1s = []
        self._current_tag = None

    def handle_starttag(self, tag, attrs):
        self._current_tag = tag
        attr_dict = dict(attrs)
        if tag == "title":
            self.in_title = True
        if tag == "meta":
            name = (attr_dict.get("name") or attr_dict.get("property") or "").lower()
            if name in {"description", "og:description"} and not self.meta_description:
                self.meta_description = attr_dict.get("content", "")[:300]

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        self._current_tag = None

    def handle_data(self, data):
        text = data.strip()
        if not text:
            return
        if self.in_title and not self.title:
            self.title = text[:200]
        if self._current_tag == "h1" and len(self.h1s) < 3:
            self.h1s.append(text[:120])


def validate_scrape_target(url: str):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Only http and https URLs are supported.")
    if not parsed.hostname:
        raise ValueError("A valid hostname is required.")
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise ValueError(f"Unable to resolve source host: {exc}") from exc
    resolved = sorted({item[4][0] for item in infos})
    if not resolved:
        raise ValueError("Could not resolve source host.")
    if any(not is_ip_allowed(ip) for ip in resolved):
        raise ValueError("This source host resolves to a local/private address and is blocked by scraper policy.")
    return parsed.geturl()


def scrape_source(url: str):
    safe_url = validate_scrape_target(url)
    req = urllib.request.Request(
        safe_url,
        headers={
            "User-Agent": "Lamprey/1.3 (+customer operations workspace)",
            "Accept": "text/html,application/xhtml+xml",
        },
        method="GET",
    )
    opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler)
    with opener.open(req, timeout=5) as resp:
        content_type = (resp.headers.get("Content-Type", "") or "").lower()
        if "html" not in content_type:
            raise ValueError("Only HTML pages are supported for Lamprey source enrichment.")
        body = resp.read(200000).decode("utf-8", errors="ignore")
    parser = SimpleHTMLScraper()
    parser.feed(body)
    emails = sorted(set(re.findall(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", body, flags=re.I)))[:3]
    phones = sorted(set(re.findall(r"(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}", body)))[:3]
    summary_parts = []
    if parser.title:
        summary_parts.append(f"Title: {parser.title}")
    if parser.meta_description:
        summary_parts.append(f"Description: {parser.meta_description}")
    if parser.h1s:
        summary_parts.append("Headings: " + "; ".join(parser.h1s))
    if emails:
        summary_parts.append("Emails found: " + ", ".join(emails))
    if phones:
        summary_parts.append("Phones found: " + ", ".join(phones))
    return {
        "source_summary": "\n".join(summary_parts)[:1200],
        "email": emails[0] if emails else "",
        "phone": phones[0] if phones else "",
        "website": safe_url,
        "source_url": safe_url,
    }


# =============================================================================
# EXTERNAL API INTEGRATIONS
# =============================================================================
# Each integration below follows the same pattern:
#
#   1. Check that required env vars are set — return [] immediately if not.
#      This keeps the app fully functional in demo mode without any credentials.
#   2. Build and send the HTTP request using only stdlib (urllib.request).
#   3. Return a normalized list of dicts that the caller can use directly.
#   4. Catch all exceptions and return [] — never let an integration crash
#      the core app.
#
# TO ACTIVATE AN INTEGRATION:
#   - Set the required environment variables listed in the CONFIG BLOCK above.
#   - Restart the server. The stub will automatically switch from demo-mode
#     (returning []) to live mode on the next request.
#
# TO ADD A NEW INTEGRATION:
#   - Copy the pattern from one of the stubs below.
#   - Add its env vars to the CONFIG BLOCK (INTEGRATION CONFIG section).
#   - Add a call to your new function inside the relevant page/save method.
#   - See the FUTURE API INTEGRATIONS scaffold further below for pre-built stubs.
# =============================================================================

# ── ZENDESK INTEGRATION ───────────────────────────────────────────────────────
# Supports: Ticket sync on the customer detail page (sidebar) and "Sync Tickets"
# Required env vars: ZENDESK_SUBDOMAIN, ZENDESK_EMAIL, ZENDESK_API_TOKEN
# Called by: sync_tickets_for_customer()
# API docs: https://developer.zendesk.com/api-reference/ticketing/tickets/tickets/
# Fetches open tickets from ZenDesk for a customer email address.
# Returns an empty list when credentials are not configured (demo/offline mode).
def fetch_zendesk_tickets(customer_email: str) -> list:
    if not ZENDESK_SUBDOMAIN or not ZENDESK_EMAIL or not ZENDESK_API_TOKEN:
        return []
    try:
        import base64
        token = base64.b64encode(f"{ZENDESK_EMAIL}/token:{ZENDESK_API_TOKEN}".encode()).decode()
        email_enc = urllib.parse.quote(customer_email)
        url = f"https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2/search.json?query=type:ticket+requester:{email_enc}+status:open"
        req = urllib.request.Request(url, headers={"Authorization": f"Basic {token}", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        results = []
        for t in (data.get("results") or [])[:20]:
            results.append({
                "external_id": str(t.get("id", "")),
                "title": (t.get("subject") or "")[:200],
                "status": (t.get("status") or "open").capitalize(),
                "priority": (t.get("priority") or "normal").capitalize(),
                "source": "zendesk",
            })
        return results
    except Exception:
        return []
# ── END ZENDESK INTEGRATION ───────────────────────────────────────────────────


# ── ARTIFACTORY INTEGRATION ───────────────────────────────────────────────────
# Supports: Build/issue sync on the customer detail page
# Required env vars: ARTIFACTORY_URL, ARTIFACTORY_API_TOKEN
# Called by: sync_tickets_for_customer()
# API docs: https://jfrog.com/help/r/jfrog-rest-apis/builds
# Fetches open issues from Artifactory linked to a customer.
# Returns an empty list when credentials are not configured (demo/offline mode).
def fetch_artifactory_issues(customer_id: str) -> list:
    if not ARTIFACTORY_URL or not ARTIFACTORY_TOKEN:
        return []
    try:
        url = f"{ARTIFACTORY_URL.rstrip('/')}/api/build/issues?customer={urllib.parse.quote(customer_id)}"
        req = urllib.request.Request(url, headers={"X-JFrog-Art-Api": ARTIFACTORY_TOKEN, "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        results = []
        for issue in (data.get("issues") or [])[:20]:
            results.append({
                "external_id": str(issue.get("issueId") or issue.get("id", "")),
                "title": (issue.get("summary") or issue.get("title") or "")[:200],
                "status": "Open",
                "priority": "Medium",
                "source": "artifactory",
            })
        return results
    except Exception:
        return []
# ── END ARTIFACTORY INTEGRATION ───────────────────────────────────────────────


# =============================================================================
# FUTURE API INTEGRATIONS — SCAFFOLD
# =============================================================================
# The stubs below are pre-wired placeholders for common integrations.
# Each one is safe to leave in place — it returns [] until env vars are set.
#
# TO ACTIVATE: set the listed env vars and call the function from the relevant
# page or save method (grep for "fetch_zendesk_tickets" to see call sites).
#
# TO WIRE A STUB INTO THE UI:
#   1. Add its env vars to the INTEGRATION CONFIG block near the top of this file.
#   2. Call the function inside the appropriate page method (e.g. ticket_detail,
#      save_ticket, or a new sync route).
#   3. Render the returned list alongside internal ticket data.
# =============================================================================

# ── SERVICENOW INTEGRATION STUB ───────────────────────────────────────────────
# Supports: Incident/change-request sync
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   SERVICENOW_INSTANCE  — e.g. "mycompany.service-now.com"
#   SERVICENOW_USER      — API username
#   SERVICENOW_PASSWORD  — API password or OAuth token
# API docs: https://developer.servicenow.com/dev.do#!/reference/api/
#
# def fetch_servicenow_incidents(customer_name: str) -> list:
#     instance  = os.environ.get("SERVICENOW_INSTANCE", "")
#     sn_user   = os.environ.get("SERVICENOW_USER", "")
#     sn_pass   = os.environ.get("SERVICENOW_PASSWORD", "")
#     if not instance or not sn_user or not sn_pass:
#         return []   # demo/offline mode — no credentials configured
#     try:
#         import base64
#         token = base64.b64encode(f"{sn_user}:{sn_pass}".encode()).decode()
#         q = urllib.parse.quote(customer_name)
#         url = f"https://{instance}/api/now/table/incident?sysparm_query=company.name={q}^state!=6&sysparm_limit=20"
#         req = urllib.request.Request(url, headers={
#             "Authorization": f"Basic {token}",
#             "Accept": "application/json",
#         })
#         with urllib.request.urlopen(req, timeout=5) as resp:
#             data = json.loads(resp.read().decode())
#         return [
#             {
#                 "external_id": r.get("sys_id", ""),
#                 "title": r.get("short_description", "")[:200],
#                 "status": r.get("state", ""),
#                 "priority": r.get("priority", ""),
#                 "source": "servicenow",
#             }
#             for r in (data.get("result") or [])
#         ]
#     except Exception:
#         return []
# ── END SERVICENOW STUB ───────────────────────────────────────────────────────


# ── PAGERDUTY INTEGRATION STUB ────────────────────────────────────────────────
# Supports: Open incident sync and alert notifications
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   PAGERDUTY_API_TOKEN  — REST API v2 token
#   PAGERDUTY_SERVICE_ID — (optional) filter to a specific PD service
# API docs: https://developer.pagerduty.com/api-reference/
#
# def fetch_pagerduty_incidents(customer_name: str) -> list:
#     pd_token = os.environ.get("PAGERDUTY_API_TOKEN", "")
#     if not pd_token:
#         return []   # demo/offline mode — no credentials configured
#     try:
#         service_id = os.environ.get("PAGERDUTY_SERVICE_ID", "")
#         url = "https://api.pagerduty.com/incidents?statuses[]=triggered&statuses[]=acknowledged"
#         if service_id:
#             url += f"&service_ids[]={service_id}"
#         req = urllib.request.Request(url, headers={
#             "Authorization": f"Token token={pd_token}",
#             "Accept": "application/vnd.pagerduty+json;version=2",
#         })
#         with urllib.request.urlopen(req, timeout=5) as resp:
#             data = json.loads(resp.read().decode())
#         return [
#             {
#                 "external_id": inc.get("id", ""),
#                 "title": inc.get("title", "")[:200],
#                 "status": inc.get("status", "").capitalize(),
#                 "priority": (inc.get("urgency") or "low").capitalize(),
#                 "source": "pagerduty",
#             }
#             for inc in (data.get("incidents") or [])
#         ]
#     except Exception:
#         return []
# ── END PAGERDUTY STUB ────────────────────────────────────────────────────────


# ── JIRA INTEGRATION STUB ─────────────────────────────────────────────────────
# Supports: Issue/bug sync linked to customer accounts
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   JIRA_BASE_URL    — e.g. "https://mycompany.atlassian.net"
#   JIRA_USER        — Atlassian account email
#   JIRA_API_TOKEN   — Atlassian API token
#   JIRA_PROJECT_KEY — (optional) filter to a specific project, e.g. "OPS"
# API docs: https://developer.atlassian.com/cloud/jira/platform/rest/v3/
#
# def fetch_jira_issues(customer_label: str) -> list:
#     base_url  = os.environ.get("JIRA_BASE_URL", "")
#     jira_user = os.environ.get("JIRA_USER", "")
#     jira_tok  = os.environ.get("JIRA_API_TOKEN", "")
#     if not base_url or not jira_user or not jira_tok:
#         return []   # demo/offline mode — no credentials configured
#     try:
#         import base64
#         token = base64.b64encode(f"{jira_user}:{jira_tok}".encode()).decode()
#         project = os.environ.get("JIRA_PROJECT_KEY", "")
#         jql = f'labels="{customer_label}" AND statusCategory != Done'
#         if project:
#             jql = f'project={project} AND ' + jql
#         url = f"{base_url.rstrip('/')}/rest/api/3/search?jql={urllib.parse.quote(jql)}&maxResults=20"
#         req = urllib.request.Request(url, headers={
#             "Authorization": f"Basic {token}",
#             "Accept": "application/json",
#         })
#         with urllib.request.urlopen(req, timeout=5) as resp:
#             data = json.loads(resp.read().decode())
#         return [
#             {
#                 "external_id": issue.get("key", ""),
#                 "title": (issue.get("fields", {}).get("summary") or "")[:200],
#                 "status": (issue.get("fields", {}).get("status", {}).get("name") or ""),
#                 "priority": (issue.get("fields", {}).get("priority", {}).get("name") or "Medium"),
#                 "source": "jira",
#             }
#             for issue in (data.get("issues") or [])
#         ]
#     except Exception:
#         return []
# ── END JIRA STUB ─────────────────────────────────────────────────────────────


# ── SLACK NOTIFICATION STUB ───────────────────────────────────────────────────
# Supports: Post a message to a Slack channel when a ticket is created/updated
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   SLACK_WEBHOOK_URL — Incoming Webhook URL from Slack app settings
# API docs: https://api.slack.com/messaging/webhooks
#
# def notify_slack(message: str) -> bool:
#     webhook = os.environ.get("SLACK_WEBHOOK_URL", "")
#     if not webhook:
#         return False   # demo/offline mode — no webhook configured
#     try:
#         payload = json.dumps({"text": message}).encode()
#         req = urllib.request.Request(webhook, data=payload, headers={"Content-Type": "application/json"})
#         with urllib.request.urlopen(req, timeout=5) as resp:
#             return resp.status == 200
#     except Exception:
#         return False
#
# USAGE EXAMPLE (inside save_ticket after conn.commit()):
#   notify_slack(f":ticket: New ticket {ticket_number} created for {customer_name}")
# ── END SLACK STUB ────────────────────────────────────────────────────────────


# ── GENERIC REST WEBHOOK STUB ─────────────────────────────────────────────────
# Supports: Outbound event notifications to any system (CI/CD, ITSM, monitoring)
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   LAMPREY_WEBHOOK_URL    — target endpoint
#   LAMPREY_WEBHOOK_SECRET — (optional) HMAC-SHA256 signing secret
# This pattern is compatible with GitHub, Datadog, and most modern event buses.
#
# def fire_webhook(event_type: str, payload: dict) -> bool:
#     url    = os.environ.get("LAMPREY_WEBHOOK_URL", "")
#     secret = os.environ.get("LAMPREY_WEBHOOK_SECRET", "")
#     if not url:
#         return False   # demo/offline mode — no webhook configured
#     try:
#         body = json.dumps({"event": event_type, "data": payload}).encode()
#         headers = {"Content-Type": "application/json"}
#         if secret:
#             sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
#             headers["X-Lamprey-Signature"] = f"sha256={sig}"
#         req = urllib.request.Request(url, data=body, headers=headers)
#         with urllib.request.urlopen(req, timeout=5) as resp:
#             return resp.status < 300
#     except Exception:
#         return False
# ── END GENERIC WEBHOOK STUB ──────────────────────────────────────────────────
# =============================================================================
# END FUTURE API INTEGRATIONS SCAFFOLD
# =============================================================================


# ── EMAIL NOTIFICATION STUB ───────────────────────────────────────────────────
# Sends an email to all named contacts on a customer record when a
# customer-visible ticket note is posted. Falls back to audit-log-only when
# EMAIL_SMTP_HOST is not configured (demo / no mail server).
#
# Supports: Ticket comment notifications to customer contacts
# Required env vars (add to INTEGRATION CONFIG block to activate):
#   EMAIL_SMTP_HOST, EMAIL_SMTP_PORT, EMAIL_SENDER, EMAIL_PASSWORD
#
# The function is called by add_ticket_note() when visibility='customer'.
# To extend it (e.g. ticket-created notifications), call it from save_ticket().
def notify_customer_contacts(
    conn: sqlite3.Connection,
    customer_id,
    subject: str,
    body: str,
    actor: str,
) -> int:
    """
    Email all contacts for customer_id where an email address is stored.
    Returns the number of addresses notified (0 in demo/no-config mode).
    Always writes an audit entry regardless of whether email is sent.
    """
    contacts = conn.execute(
        "SELECT name, email FROM customer_contacts WHERE customer_id=? AND email != ''",
        (customer_id,),
    ).fetchall()
    if not contacts:
        return 0

    recipients = [c["email"] for c in contacts if c["email"]]
    conn.execute(
        "INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'notify_contacts', ?, ?)",
        (actor, customer_id, json.dumps({"subject": subject, "recipients": recipients})),
    )

    if not EMAIL_SMTP_HOST or not EMAIL_SENDER:
        # Demo / no mail server — notification recorded in audit log only
        return 0

    # ── LIVE EMAIL PATH ────────────────────────────────────────────────────────
    # Uses stdlib smtplib — no third-party library required.
    # Activate by setting EMAIL_SMTP_HOST, EMAIL_SMTP_PORT, EMAIL_SENDER, EMAIL_PASSWORD.
    try:
        import smtplib
        from email.mime.text import MIMEText
        sent = 0
        for email_addr in recipients:
            msg = MIMEText(body, "plain", "utf-8")
            msg["Subject"] = subject
            msg["From"] = EMAIL_SENDER
            msg["To"] = email_addr
            with smtplib.SMTP(EMAIL_SMTP_HOST, EMAIL_SMTP_PORT, timeout=5) as smtp:
                smtp.ehlo()
                smtp.starttls()
                if EMAIL_PASSWORD:
                    smtp.login(EMAIL_SENDER, EMAIL_PASSWORD)
                smtp.sendmail(EMAIL_SENDER, [email_addr], msg.as_string())
            sent += 1
        return sent
    except Exception:
        return 0
# ── END EMAIL NOTIFICATION STUB ───────────────────────────────────────────────


# =============================================================================
# EXTERNAL SOURCE-OF-TRUTH HELPERS
# =============================================================================
# These two functions are the single write path for ALL external data entering
# Lamprey — from ZenDesk, Artifactory, and any future integration stub above.
#
# DESIGN PRINCIPLE:
#   External data is treated as authoritative. When an external system provides
#   a value for a field, that value overwrites whatever is currently stored in
#   Lamprey, regardless of local edits. This ensures the CMDB stays in sync
#   with upstream systems of record.
#
#   The only exception is fields the external source leaves absent (None / "").
#   A missing value from an external source means "I have nothing to say about
#   this field" — in that case the local value is preserved untouched.
#
# HOW TO CALL FROM A NEW INTEGRATION:
#   conn = db_conn()
#   # Update customer fields from an external payload:
#   apply_external_customer_update(conn, customer_id, {
#       "status": "Active",
#       "email":  "ops@customer.example",
#   }, source_name="myintegration", actor="system")
#
#   # Upsert a ticket (create or update, external wins):
#   upsert_external_ticket(conn, customer_id, {
#       "external_id": "EXT-999",
#       "title":       "Disk failure on node-04",
#       "status":      "Open",
#       "priority":    "Critical",
#       "source":      "myintegration",
#   }, actor="system")
#
#   conn.commit()
#   conn.close()
# =============================================================================

# ── ALLOWED CUSTOMER FIELDS ────────────────────────────────────────────────────
# The set of customer columns that an external source may write.
# This whitelist prevents external payloads from overwriting internal-only fields
# such as created_by, updated_by, id, or the sync tracking columns themselves.
# TO ALLOW A NEW FIELD: add its column name here.
EXTERNAL_CUSTOMER_WRITABLE_FIELDS = {
    "company_name",
    "status",
    "customer_type",
    "region",
    "primary_contact",
    "email",
    "phone",
    "website",
    "address",
    "notes",
    "source_summary",
    "source_url",
}


def apply_external_customer_update(
    conn: sqlite3.Connection,
    customer_id,
    fields: dict,
    source_name: str,
    actor: str,
) -> dict:
    """
    Apply a dict of field updates from an external source to a customer record.
    External values always overwrite local values when present and non-empty.
    Fields absent from `fields` (or set to None / "") leave the existing
    database value untouched.

    Returns a dict of {"field": (old_value, new_value)} for every field that
    actually changed — useful for building a detailed audit entry.

    Raises ValueError if customer_id does not exist.
    """
    row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    if not row:
        raise ValueError(f"Customer {customer_id} not found.")

    # Filter to allowed writable fields only
    updates = {
        k: v for k, v in fields.items()
        if k in EXTERNAL_CUSTOMER_WRITABLE_FIELDS and v not in (None, "")
    }
    if not updates:
        return {}

    # Detect what actually changed so we can write a meaningful audit entry
    changed = {k: (row[k], v) for k, v in updates.items() if row[k] != v}
    if not changed:
        return {}

    set_clause = ", ".join(f"{col}=?" for col in updates)
    values = list(updates.values())
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    conn.execute(
        f"UPDATE customers SET {set_clause}, last_synced_at=?, sync_source=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (*values, ts, source_name, actor, customer_id),
    )
    conn.execute(
        "INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'external_customer_update', ?, ?)",
        (actor, customer_id, json.dumps({
            "source": source_name,
            "changed": {k: {"from": old, "to": new} for k, (old, new) in changed.items()},
        })),
    )
    return changed


def upsert_external_ticket(
    conn: sqlite3.Connection,
    customer_id,
    ticket_data: dict,
    actor: str,
) -> str:
    """
    Insert or update a ticket from an external source.
    Matches on (external_id, source). If a match exists the ticket's title,
    status, and priority are updated with the external values (source of truth).
    If no match exists a new ticket row is created.

    ticket_data keys:
        external_id  — unique identifier in the external system (required)
        source       — integration name: 'zendesk', 'artifactory', etc. (required)
        title        — ticket subject / summary
        status       — Open | In Progress | Resolved | Closed
        priority     — Critical | High | Medium | Low
        description  — (optional) longer body text

    Returns "created" or "updated".
    """
    ext_id = str(ticket_data.get("external_id", ""))
    source = str(ticket_data.get("source", "external"))
    title = (ticket_data.get("title") or "")[:200]
    status = ticket_data.get("status") or "Open"
    priority = ticket_data.get("priority") or "Medium"
    description = (ticket_data.get("description") or "")[:3000]

    existing = conn.execute(
        "SELECT id FROM tickets WHERE external_id=? AND source=?", (ext_id, source)
    ).fetchone()

    if existing:
        # External source wins — overwrite title, status, priority unconditionally
        conn.execute(
            """UPDATE tickets
               SET title=?, status=?, priority=?, description=COALESCE(NULLIF(?,''),(SELECT description FROM tickets WHERE id=?)),
                   updated_by=?, updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (title, status, priority, description, existing["id"], actor, existing["id"]),
        )
        conn.execute(
            "INSERT INTO audit_log (actor, action, ticket_id, details) VALUES (?, 'external_ticket_update', ?, ?)",
            (actor, existing["id"], json.dumps({"source": source, "external_id": ext_id,
                                                 "title": title, "status": status, "priority": priority})),
        )
        return "updated"
    else:
        cur = conn.cursor()
        tmp = f"TMP-{secrets.token_hex(6)}"
        cur.execute(
            """INSERT INTO tickets
               (ticket_number, customer_id, title, description, status, priority, source, external_id, created_by, updated_by)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (tmp, customer_id, title, description, status, priority, source, ext_id, actor, actor),
        )
        ticket_id = cur.lastrowid
        conn.execute("UPDATE tickets SET ticket_number=? WHERE id=?", (f"TKT-{ticket_id:04d}", ticket_id))
        conn.execute(
            "INSERT INTO audit_log (actor, action, ticket_id, customer_id, details) VALUES (?, 'external_ticket_create', ?, ?, ?)",
            (actor, ticket_id, customer_id, json.dumps({"source": source, "external_id": ext_id})),
        )
        return "created"
# =============================================================================
# END EXTERNAL SOURCE-OF-TRUTH HELPERS
# =============================================================================


# =============================================================================
# LOG EXPORTER
# =============================================================================
# Runs as a daemon background thread. On each tick it reads the next batch of
# audit_log rows that have not yet been exported (using a watermark stored in
# data/log_export_watermark) and ships them to the configured destination.
#
# Supported destinations (configured via env vars in the INTEGRATION CONFIG block):
#   HTTP/HTTPS  — LOG_EXPORT_URL          (Elasticsearch, Splunk HEC, Loki, etc.)
#   Syslog      — LOG_EXPORT_SYSLOG_HOST  (Graylog, rsyslog, any RFC-5424 receiver)
#
# Both destinations can be active simultaneously. If neither is configured the
# thread sleeps quietly and does nothing — zero overhead when export is disabled.
#
# Watermark: the last successfully exported audit_log.id is written to
#   data/log_export_watermark (plain integer, one line).
# If the file is missing, export starts from id=0 (all history).
# The watermark is only advanced after a successful export — a failed batch is
# retried on the next tick without skipping any rows.
#
# TO ENABLE HTTP EXPORT:
#   export LOG_EXPORT_URL="https://your-log-server/ingest"
#   export LOG_EXPORT_API_KEY="your-bearer-token"   # optional
#
# TO ENABLE SYSLOG EXPORT:
#   export LOG_EXPORT_SYSLOG_HOST="192.168.1.50"
#   export LOG_EXPORT_SYSLOG_PORT="514"             # default
#   export LOG_EXPORT_SYSLOG_PROTO="udp"            # or "tcp"
#
# TO QUERY EXPORTED LOGS VIA API (examples):
#   Elasticsearch: GET /lamprey-audit/_search?q=actor:admin
#   Splunk HEC:    search index=lamprey sourcetype=audit_log
#   Loki:          {job="lamprey"} |= "delete_customer"
# =============================================================================

def _read_export_watermark() -> int:
    """Return the last successfully exported audit_log.id (0 if no watermark yet)."""
    try:
        return int(LOG_EXPORT_WATERMARK_FILE.read_text().strip())
    except (FileNotFoundError, ValueError):
        return 0


def _write_export_watermark(last_id: int):
    """Persist the watermark so the next run picks up where we left off."""
    LOG_EXPORT_WATERMARK_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOG_EXPORT_WATERMARK_FILE.write_text(str(last_id))


def _audit_row_to_dict(row) -> dict:
    """Convert a sqlite3.Row from audit_log to a plain dict for serialisation."""
    return {
        "id":          row["id"],
        "actor":       row["actor"],
        "action":      row["action"],
        "customer_id": row["customer_id"],
        "ticket_id":   row["ticket_id"],
        "details":     row["details"],
        "created_at":  row["created_at"],
        "source":      "lamprey",
    }


def _export_batch_http(rows: list[dict]) -> bool:
    """
    POST a batch of audit rows to LOG_EXPORT_URL.
    Format: ndjson (one JSON object per line) or json_array.
    Returns True on success, False on any error.
    """
    if not LOG_EXPORT_URL:
        return True  # HTTP export not configured — treat as success
    try:
        if LOG_EXPORT_FORMAT == "json_array":
            body = json.dumps(rows).encode()
            content_type = "application/json"
        else:  # ndjson (default) — compatible with Elasticsearch _bulk, Loki, etc.
            body = b"\n".join(json.dumps(r).encode() for r in rows) + b"\n"
            content_type = "application/x-ndjson"
        headers = {"Content-Type": content_type, "User-Agent": "Lamprey/1.0"}
        if LOG_EXPORT_API_KEY:
            headers["Authorization"] = f"Bearer {LOG_EXPORT_API_KEY}"
        req = urllib.request.Request(LOG_EXPORT_URL, data=body, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status >= 300:
                log.warning("log_exporter: HTTP export got status %s", resp.status)
                return False
        return True
    except Exception as exc:
        log.warning("log_exporter: HTTP export failed — %s", exc)
        return False


def _export_batch_syslog(rows: list[dict]) -> bool:
    """
    Send each audit row as an RFC-5424-style syslog message to LOG_EXPORT_SYSLOG_HOST.
    PRI = 134 (facility=16/local0, severity=6/informational).
    Returns True on success, False on any error.
    """
    if not LOG_EXPORT_SYSLOG_HOST:
        return True  # syslog not configured — treat as success
    PRI = "<134>"
    hostname = socket.gethostname()
    try:
        if LOG_EXPORT_SYSLOG_PROTO == "tcp":
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((LOG_EXPORT_SYSLOG_HOST, LOG_EXPORT_SYSLOG_PORT))
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        with sock:
            for row in rows:
                ts = row.get("created_at", "")
                msg_body = json.dumps({k: v for k, v in row.items() if k not in ("created_at",)})
                message = f"{PRI}1 {ts} {hostname} lamprey - - - {msg_body}"
                payload = message.encode("utf-8", errors="replace")
                if LOG_EXPORT_SYSLOG_PROTO == "tcp":
                    sock.sendall(payload + b"\n")
                else:
                    sock.sendto(payload, (LOG_EXPORT_SYSLOG_HOST, LOG_EXPORT_SYSLOG_PORT))
        return True
    except Exception as exc:
        log.warning("log_exporter: syslog export failed — %s", exc)
        return False


def log_exporter_worker(stop_event: threading.Event):
    """
    Background daemon thread. Wakes every LOG_EXPORT_INTERVAL_SECONDS seconds,
    reads unsent audit_log rows, ships them, and advances the watermark.
    Stops cleanly when stop_event is set (on server shutdown).
    """
    log.info("log_exporter: started (interval=%ss, http=%s, syslog=%s)",
             LOG_EXPORT_INTERVAL_SECONDS,
             "enabled" if LOG_EXPORT_URL else "disabled",
             "enabled" if LOG_EXPORT_SYSLOG_HOST else "disabled")
    while not stop_event.wait(timeout=LOG_EXPORT_INTERVAL_SECONDS):
        try:
            watermark = _read_export_watermark()
            conn = db_conn()
            rows_raw = conn.execute(
                "SELECT id, actor, action, customer_id, ticket_id, details, created_at "
                "FROM audit_log WHERE id > ? ORDER BY id ASC LIMIT ?",
                (watermark, LOG_EXPORT_BATCH_SIZE)
            ).fetchall()
            conn.close()
            if not rows_raw:
                continue
            rows = [_audit_row_to_dict(r) for r in rows_raw]
            http_ok    = _export_batch_http(rows)
            syslog_ok  = _export_batch_syslog(rows)
            if http_ok and syslog_ok:
                new_watermark = rows[-1]["id"]
                _write_export_watermark(new_watermark)
                log.info("log_exporter: exported %d rows (watermark → %d)", len(rows), new_watermark)
            else:
                log.warning("log_exporter: export failed — will retry next tick (watermark unchanged at %d)", watermark)
        except Exception as exc:
            log.error("log_exporter: unexpected error — %s", exc)
    log.info("log_exporter: stopped")

# ── END LOG EXPORTER ──────────────────────────────────────────────────────────

# ── HTML RENDERING HELPERS ────────────────────────────────────────────────────
# query_params(path) — parse URL query string into a plain dict
# esc(s)             — HTML-escape any string before inserting into HTML
#                      ALWAYS use esc() around user-supplied values in f-strings
# render_page()      — master page template: injects nav, flash, warning, body
#                      Returns bytes (already UTF-8 encoded) ready for wfile.write
#
# TO ADD A NEW NAV ITEM:
#   1. Add an <a href="...">Label</a> line inside the navlinks div in render_page.
#   2. If it should be role-gated, wrap it in a conditional like _users_link.
#   3. Add a matching route in do_GET / do_POST below.
def query_params(path: str) -> dict:
    return {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(path).query).items()}


def esc(s: str) -> str:
    """HTML-escape a string. Always wrap user-supplied content with esc()."""
    return html.escape(s or "")


# render_page() — master HTML template
# Parameters:
#   title   — used in the browser tab <title> tag
#   body    — the page-specific HTML content (injected into <main>)
#   session — if None, the public (login) nav is shown instead of the full nav
#   message — green flash message shown at the top of <main>
#   warning — yellow warning banner shown above the flash (e.g. demo mode notice)
def render_page(title: str, body: str, session: dict | None = None, message: str = "", warning: str = ""):
    if session:
        _role = session.get("role", "")
        _users_link = '<a href="/users">Users</a>' if _role in ("admin", "engineer") else ""
        nav = f'''
        <nav class="topnav">
          <div class="brand-wrap">
            <a class="brandmark" href="/dashboard" aria-label="Lamprey dashboard">
              <img src="/static/logo.svg" alt="Lamprey logo">
              <span class="wordmark">
                <strong>Lamprey</strong>
                <small>Customer Operations Workspace</small>
              </span>
            </a>
          </div>
          <div class="navlinks">
            <a href="/dashboard">Dashboard</a>
            <a href="/customers">Customers</a>
            <a href="/tickets">Tickets</a>
            {_users_link}
            <a href="/audit">Audit Log</a>
            <a href="/logout">Logout ({esc(session.get("username"))})</a>
          </div>
        </nav>
        '''
    else:
        nav = '''
        <nav class="topnav topnav-public">
          <div class="brand-wrap">
            <div class="brandmark" aria-label="Lamprey sign in">
              <img src="/static/logo.svg" alt="Lamprey logo">
              <span class="wordmark">
                <strong>Lamprey</strong>
                <small>Customer Operations Workspace</small>
              </span>
            </div>
          </div>
        </nav>
        '''
    flash = f'<div class="flash">{esc(message)}</div>' if message else ''
    warn = f'<div class="warning">{esc(warning)}</div>' if warning else ''
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lamprey | {esc(title)}</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  {nav}
  <main class="page-shell">
    {warn}
    {flash}
    {body}
  </main>
</body>
</html>'''.encode()


# ── DASHBOARD METRICS ─────────────────────────────────────────────────────────
# card_metrics() queries the three summary counters shown on the dashboard.
# To add a new metric card:
#   1. Add a query here and return the value.
#   2. Add an <article class="metric card"> block in dashboard_page().
#   3. Add a column to .metrics-grid in style.css (update grid-template-columns).
def card_metrics(conn):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM customers")
    total = cur.fetchone()["c"]
    # Count distinct engineers and technicians with a currently valid session.
    # A session is "active" if it has not exceeded the absolute TTL and the user
    # has been seen within the idle window. This mirrors the same checks in
    # read_session() so the count stays consistent with who can actually load pages.
    ts = now_ts()
    cur.execute(
        """
        SELECT COUNT(DISTINCT s.username) AS c
        FROM sessions s
        JOIN users u ON u.username = s.username
        WHERE s.expires_ts > ?
          AND s.last_seen_ts > ?
          AND u.role IN ('engineer', 'technician')
          AND u.is_active = 1
        """,
        (ts, ts - SESSION_IDLE_SECONDS),
    )
    online = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) AS c FROM tickets WHERE status NOT IN ('Resolved','Closed')")
    open_tickets = cur.fetchone()["c"]
    return total, online, open_tickets


# ── STATUS & PRIORITY BADGES ──────────────────────────────────────────────────
# priority_badge() / status_badge() return an HTML <span> with the correct CSS
# class for color coding. Badge styles live in style.css under BADGE section.
# To add a new priority or status value:
#   1. Add it to the dict below.
#   2. Add a matching .badge-<name> rule in style.css.
def priority_badge(p: str) -> str:
    cls = {"Critical": "badge-critical", "High": "badge-high",
           "Medium": "badge-medium", "Low": "badge-low"}.get(p, "badge-low")
    return f'<span class="badge {cls}">{esc(p)}</span>'


def status_badge(s: str) -> str:
    cls = {"Open": "badge-open", "In Progress": "badge-in-progress",
           "Resolved": "badge-resolved", "Closed": "badge-closed"}.get(s, "badge-open")
    return f'<span class="badge {cls}">{esc(s)}</span>'
# ── END BADGE HELPERS ─────────────────────────────────────────────────────────


# =============================================================================
# HTTP REQUEST HANDLER
# =============================================================================
# AppHandler extends BaseHTTPRequestHandler and handles every HTTP request.
# All page logic lives as methods on this class.
#
# REQUEST LIFECYCLE (for authenticated pages):
#   do_GET / do_POST
#     → parse path
#     → call self.current_session() to validate cookie
#     → call self.require_admin() or self.require_engineer() if needed
#     → call the relevant page method (e.g. self.dashboard_page(session))
#     → page method calls self.send_html() or self.send_redirect()
#
# ADDING A NEW PAGE:
#   1. Add a route in do_GET (GET handler) and/or do_POST (POST handler).
#   2. Create a method: def my_page(self, session): ... self.send_html(...)
#   3. Optionally add a nav link in render_page() above.
#   4. If the page modifies data, write an INSERT to audit_log in the method.
# =============================================================================
class AppHandler(BaseHTTPRequestHandler):
    server_version = "Lamprey/1.3"

    def log_message(self, fmt, *args):
        # Suppress default access log output to keep the console clean.
        # To re-enable: remove this method or call super().log_message(fmt, *args)
        return

    def client_ip(self) -> str:
        return self.client_address[0] if self.client_address else "unknown"

    # ── SECURITY HEADERS ──────────────────────────────────────────────────────
    # Applied to every response. These headers defend against clickjacking,
    # MIME-sniffing, cross-origin data leaks, and inline script injection.
    # Do not remove headers without understanding the attack they mitigate.
    def security_headers(self):
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Cache-Control", "no-store")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'self'; img-src 'self' data:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'",
        )

    def send_html(self, status: int, content: bytes):
        self.send_response(status)
        self.security_headers()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(content)

    def send_redirect(self, location: str):
        self.send_response(303)
        self.security_headers()
        self.send_header("Location", location)
        self.end_headers()

    def get_session_cookie(self):
        raw = self.headers.get("Cookie", "")
        jar = cookies.SimpleCookie()
        jar.load(raw)
        sess = jar.get(SESSION_NAME)
        csrf = jar.get(CSRF_NAME)
        return (sess.value if sess else None), (csrf.value if csrf else None)

    def current_session(self):
        session_cookie, csrf_cookie = self.get_session_cookie()
        if not session_cookie:
            return None
        conn = db_conn()
        cleanup_db_state(conn)
        session = read_session(conn, session_cookie, self.headers.get("User-Agent", ""))
        conn.close()
        if not session:
            return None
        if csrf_cookie and not hmac.compare_digest(csrf_cookie, session["csrf_token"]):
            return None
        return session

    def set_session(self, username: str):
        conn = db_conn()
        cleanup_db_state(conn)
        session_id, csrf_token = make_session(conn, username, self.client_ip(), self.headers.get("User-Agent", ""))
        conn.close()
        secure = "; Secure" if COOKIE_SECURE else ""
        self.send_header("Set-Cookie", f"{SESSION_NAME}={session_id}; HttpOnly; SameSite=Lax; Path=/{secure}")
        self.send_header("Set-Cookie", f"{CSRF_NAME}={csrf_token}; SameSite=Lax; Path=/{secure}")

    def clear_session(self):
        session_cookie, _ = self.get_session_cookie()
        if session_cookie:
            conn = db_conn()
            destroy_session(conn, session_cookie)
            conn.close()
        self.send_header("Set-Cookie", f"{SESSION_NAME}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax; Path=/")
        self.send_header("Set-Cookie", f"{CSRF_NAME}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax; Path=/")

    def read_form(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > MAX_BODY_BYTES:
            raise ValueError("Invalid form payload size.")
        content_type = self.headers.get("Content-Type", "")
        if "application/x-www-form-urlencoded" not in content_type:
            raise ValueError("Unsupported content type.")
        data = self.rfile.read(length).decode("utf-8", errors="ignore")
        parsed = urllib.parse.parse_qs(data, keep_blank_values=True)
        return {k: v[0].strip() for k, v in parsed.items()}

    def require_csrf(self, session):
        form = self.read_form()
        token = form.get("csrf_token", "")
        if not token or not hmac.compare_digest(token, session["csrf_token"]):
            raise PermissionError("Invalid CSRF token.")
        host = self.headers.get("Host", "")
        if not safe_same_origin(self.headers.get("Origin", ""), host):
            raise PermissionError("Origin validation failed.")
        if not safe_same_origin(self.headers.get("Referer", ""), host):
            raise PermissionError("Referer validation failed.")
        return form

    def serve_static(self, path):
        rel = path.replace("/static/", "", 1)
        file_path = (STATIC_DIR / rel).resolve()
        if not str(file_path).startswith(str(STATIC_DIR.resolve())) or not file_path.exists() or not file_path.is_file():
            self.send_error_page(404, "Not found")
            return
        ctype = "text/css; charset=utf-8" if file_path.suffix == ".css" else ("image/svg+xml" if file_path.suffix == ".svg" else "application/octet-stream")
        self.send_response(200)
        self.security_headers()
        self.send_header("Content-Type", ctype)
        self.end_headers()
        self.wfile.write(file_path.read_bytes())

    def send_error_page(self, status: int, message: str):
        self.send_html(status, render_page(f"Error {status}", f"<section class='card slim'><h1>Error {status}</h1><p>{esc(message)}</p></section>"))

    def csrf_input(self, session):
        return f'<input type="hidden" name="csrf_token" value="{esc(session["csrf_token"])}">'

    # ── DEMO MODE BANNER ──────────────────────────────────────────────────────
    # Returns the demo mode warning string when the default admin password is
    # still in use. The banner text is controlled by DEMO_WARNING_MESSAGE above.
    # Returns an empty string (no banner) when a custom password is set.
    def app_warning(self):
        if DEFAULT_ADMIN_PASSWORD == "admin123!":
            return DEMO_WARNING_MESSAGE
        return ""
    # ── END DEMO MODE BANNER ──────────────────────────────────────────────────

    # ── ROLE-BASED ACCESS CONTROL ─────────────────────────────────────────────
    # Lamprey has three roles in ascending privilege order:
    #   technician — read customer data, create tickets, add ticket notes
    #   engineer   — all technician rights + add/edit customers, add technicians,
    #                edit/close tickets
    #   admin      — all engineer rights + manage/delete all users and customers
    #
    # Use require_admin() or require_engineer() at the top of any route handler
    # that must be restricted. They raise PermissionError which do_POST catches
    # and converts to a 403 response.
    #
    # TO ADD A NEW ROLE:
    #   1. Add a new require_<role>() method here.
    #   2. Update save_user() to allow the new role value.
    #   3. Update the role dropdown in user_form().
    #   4. Gate the relevant routes with the new checker.
    def require_admin(self, session):
        """Raises PermissionError unless the caller is an admin."""
        if session.get("role") != "admin":
            raise PermissionError("Administrator access is required for this page.")

    def require_engineer(self, session):
        """Raises PermissionError unless the caller is an engineer or admin.
        Engineers and admins may create/edit customers and manage tickets.
        Technicians are read-only on customer data and cannot edit/close tickets."""
        if session.get("role") not in ("admin", "engineer"):
            raise PermissionError("Engineer or administrator access is required for this action.")

    # ── END RBAC ──────────────────────────────────────────────────────────────

    # ── GET ROUTER ────────────────────────────────────────────────────────────
    # do_GET handles all HTTP GET requests.
    # Routes are matched top-to-bottom with simple string comparisons.
    # More-specific patterns (e.g. /users/<id>/delete) must appear BEFORE
    # catch-all patterns (e.g. /users/<id>) to avoid swallowing the suffix.
    #
    # ROUTE PATTERN REFERENCE:
    #   path == "/exact"              — exact match
    #   path.startswith("/prefix/")   — any path under this prefix
    #   path.endswith("/suffix")      — path ending with this suffix
    #   path.split("/")[2]            — extract the ID segment from /resource/<id>/action
    #
    # TO ADD A NEW GET ROUTE:
    #   if path == "/my-page":
    #       return self.my_page(session)
    def do_GET(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path.startswith("/static/"):
                return self.serve_static(path)
            if path == "/":
                session = self.current_session()
                return self.send_redirect("/dashboard" if session else "/login")
            if path == "/login":
                return self.login_page(query_params(self.path).get("error", ""))
            if path == "/logout":
                self.send_response(303)
                self.security_headers()
                self.clear_session()
                self.send_header("Location", "/login")
                self.end_headers()
                return
            session = self.current_session()
            if not session:
                return self.send_redirect("/login")
            if path == "/dashboard":
                return self.dashboard_page(session)
            if path == "/online":
                return self.online_users_page(session)
            if path == "/customers":
                return self.customers_list_page(session)
            if path == "/customers/new":
                self.require_engineer(session)
                return self.customer_form(session)
            if path.startswith("/customers/") and path.endswith("/contacts/new"):
                self.require_engineer(session)
                customer_id = path.split("/")[2]
                return self.customer_contact_form(session, customer_id)
            if path == "/users":
                self.require_engineer(session)
                return self.users_page(session)
            if path == "/users/new":
                self.require_engineer(session)
                return self.user_form(session)
            if path.startswith("/users/") and path.endswith("/edit"):
                self.require_admin(session)
                user_id = path.split("/")[2]
                return self.user_form(session, user_id)
            if path.startswith("/users/") and path.endswith("/delete"):
                self.require_admin(session)
                user_id = path.split("/")[2]
                return self.delete_user_confirm(session, user_id)
            if path.startswith("/customers/") and path.endswith("/delete"):
                self.require_admin(session)
                customer_id = path.split("/")[2]
                return self.delete_customer_confirm(session, customer_id)
            if path.startswith("/customers/") and path.endswith("/edit"):
                self.require_engineer(session)
                customer_id = path.split("/")[2]
                return self.customer_form(session, customer_id)
            if path == "/audit":
                return self.audit_log_page(session)
            if path.startswith("/customers/"):
                customer_id = path.split("/")[2]
                return self.customer_detail(session, customer_id)
            if path == "/tickets":
                return self.tickets_page(session)
            if path == "/tickets/new":
                return self.ticket_form(session)
            if path.startswith("/tickets/") and path.endswith("/edit"):
                return self.ticket_form(session, path.split("/")[2])
            if path.startswith("/tickets/"):
                return self.ticket_detail(session, path.split("/")[2])
            self.send_error_page(404, "The requested page was not found.")
        except Exception as exc:
            self.server_error(exc)

    # ── POST ROUTER ───────────────────────────────────────────────────────────
    # do_POST handles all HTTP POST requests (form submissions).
    # All POST handlers call self.require_csrf(session) first, which reads the
    # form body AND validates the CSRF token in one step.
    # The returned form dict is safe to use after require_csrf() succeeds.
    #
    # Error handling:
    #   PermissionError → 403 response
    #   ValueError      → 400 response (bad user input)
    #   Exception       → 500 response (server_error)
    #
    # TO ADD A NEW POST ROUTE:
    #   if path == "/my-page":
    #       self.require_engineer(session)   # if access-controlled
    #       return self.save_my_thing(session)
    def do_POST(self):
        try:
            path = urllib.parse.urlparse(self.path).path
            if path == "/login":
                return self.handle_login()
            session = self.current_session()
            if not session:
                return self.send_redirect("/login")
            if path == "/customers/new":
                self.require_engineer(session)
                return self.save_customer(session)
            if path.startswith("/customers/") and path.endswith("/edit"):
                self.require_engineer(session)
                return self.save_customer(session, path.split("/")[2])
            if path.startswith("/customers/") and path.endswith("/enrich"):
                self.require_engineer(session)
                return self.enrich_customer(session, path.split("/")[2])
            if path == "/users/new":
                self.require_engineer(session)
                return self.save_user(session)
            if path.startswith("/users/") and path.endswith("/edit"):
                self.require_admin(session)
                return self.save_user(session, path.split("/")[2])
            if path.startswith("/users/") and path.endswith("/delete"):
                self.require_admin(session)
                return self.delete_user(session, path.split("/")[2])
            if path.startswith("/customers/") and path.endswith("/delete"):
                self.require_admin(session)
                return self.delete_customer(session, path.split("/")[2])
            if path.startswith("/customers/") and path.endswith("/contacts/new"):
                self.require_engineer(session)
                return self.save_customer_contact(session, path.split("/")[2])
            if re.match(r"^/customers/\d+/contacts/\d+/delete$", path):
                self.require_engineer(session)
                parts = path.split("/")
                return self.delete_customer_contact(session, parts[2], parts[4])
            if path == "/tickets/new":
                return self.save_ticket(session)
            if path.startswith("/tickets/") and path.endswith("/edit"):
                self.require_engineer(session)
                return self.save_ticket(session, path.split("/")[2])
            if path.startswith("/tickets/") and path.endswith("/close"):
                self.require_engineer(session)
                return self.close_ticket(session, path.split("/")[2])
            if path.startswith("/tickets/") and path.endswith("/comment"):
                return self.add_ticket_note(session, path.split("/")[2])
            if path.startswith("/customers/") and path.endswith("/sync_tickets"):
                return self.sync_tickets_for_customer(session, path.split("/")[2])
            self.send_error_page(404, "The requested page was not found.")
        except PermissionError as exc:
            self.send_error_page(403, str(exc))
        except ValueError as exc:
            self.send_error_page(400, str(exc))
        except Exception as exc:
            self.server_error(exc)

    # ── LOGIN / AUTH PAGES ────────────────────────────────────────────────────
    # login_page()       — renders the sign-in form (no session required)
    # login_is_limited() — checks login_failures table for rate-limit condition
    # record_login_attempt() — writes to login_failures; clears failures on success
    # handle_login()     — POST handler: validates credentials, sets session cookie
    #
    # The login form intentionally shows no demo credentials in the UI.
    # Rate limiting is per (username, IP) pair — see LOGIN_* constants above.
    def login_page(self, error=""):
        body = f'''
        <section class="login-card card slim">
          <div>
            <p class="eyebrow">Lamprey</p>
            <h1>Technician Login</h1>
            <p class="muted">Local Lamprey user accounts are stored in the application database for this intranet deployment.</p>
          </div>
          <form method="post" action="/login" class="stack-form">
            <label>Username<input name="username" autocomplete="username" required maxlength="64"></label>
            <label>Password<input type="password" name="password" autocomplete="current-password" required maxlength="256"></label>
            {f'<p class="error">{esc(error)}</p>' if error else ''}
            <button class="btn btn-primary" type="submit">Sign in</button>
          </form>
        </section>
        '''
        self.send_html(200, render_page("Login", body, warning=self.app_warning()))

    def login_is_limited(self, conn: sqlite3.Connection, username: str, remote_addr: str):
        cutoff = now_ts() - LOGIN_WINDOW_SECONDS
        row = conn.execute(
            "SELECT COUNT(*) AS failures, MAX(attempted_ts) AS last_attempt FROM login_failures WHERE success = 0 AND username = ? AND remote_addr = ? AND attempted_ts >= ?",
            (username, remote_addr, cutoff),
        ).fetchone()
        failures = row["failures"] if row else 0
        last_attempt = row["last_attempt"] if row and row["last_attempt"] else 0
        return failures >= LOGIN_MAX_FAILURES and last_attempt >= now_ts() - LOGIN_LOCK_SECONDS

    def record_login_attempt(self, conn: sqlite3.Connection, username: str, remote_addr: str, success: bool):
        conn.execute(
            "INSERT INTO login_failures (username, remote_addr, attempted_ts, success) VALUES (?, ?, ?, ?)",
            (username, remote_addr, now_ts(), 1 if success else 0),
        )
        if success:
            cutoff = now_ts() - LOGIN_WINDOW_SECONDS
            conn.execute(
                "DELETE FROM login_failures WHERE username = ? AND remote_addr = ? AND attempted_ts >= ?",
                (username, remote_addr, cutoff),
            )
        conn.commit()

    def handle_login(self):
        form = self.read_form()
        username = normalize_text(form.get("username", ""), 64)
        password = form.get("password", "")[:256]
        conn = db_conn()
        cleanup_db_state(conn)
        if self.login_is_limited(conn, username, self.client_ip()):
            conn.close()
            return self.login_page("Too many failed login attempts. Please wait and try again.")
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        ok = bool(user and int(user["is_active"] or 0) == 1 and verify_password(password, user["password_salt"], user["password_hash"]))
        self.record_login_attempt(conn, username, self.client_ip(), ok)
        conn.close()
        if not ok:
            return self.login_page("Invalid username or password.")
        self.send_response(303)
        self.security_headers()
        self.set_session(username)
        self.send_header("Location", "/dashboard")
        self.end_headers()

    # ── ONLINE USERS PAGE ─────────────────────────────────────────────────────
    # online_users_page() — shows all engineers and technicians with an active
    # non-expired session. Accessible to all roles (all logged-in users can see
    # who is currently on the system). Searchable by username, display name, or
    # department. The count on the dashboard metric card links here.
    #
    # "Online" definition: session has not exceeded SESSION_TTL_SECONDS (absolute)
    # AND the user was seen within SESSION_IDLE_SECONDS (idle timeout). This is
    # the same logic used in read_session() and card_metrics().
    def online_users_page(self, session: dict):
        import urllib.parse
        params = query_params(self.path)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0].strip()
        ts = now_ts()
        conn = db_conn()
        base_sql = """
            SELECT DISTINCT u.username, u.display_name, u.role, u.department,
                   MAX(s.last_seen_ts) AS last_seen
            FROM sessions s
            JOIN users u ON u.username = s.username
            WHERE s.expires_ts > ?
              AND s.last_seen_ts > ?
              AND u.role IN ('engineer', 'technician')
              AND u.is_active = 1
        """
        idle_cutoff = ts - SESSION_IDLE_SECONDS
        if q:
            rows = conn.execute(
                base_sql + """
              AND (u.username LIKE ? OR u.display_name LIKE ? OR u.department LIKE ?)
            GROUP BY u.username ORDER BY last_seen DESC
                """,
                (ts, idle_cutoff, f"%{q}%", f"%{q}%", f"%{q}%"),
            ).fetchall()
        else:
            rows = conn.execute(
                base_sql + " GROUP BY u.username ORDER BY last_seen DESC",
                (ts, idle_cutoff),
            ).fetchall()
        conn.close()

        def fmt_ago(last_ts):
            diff = ts - (last_ts or 0)
            if diff < 60:
                return "just now"
            if diff < 3600:
                return f"{diff // 60}m ago"
            return f"{diff // 3600}h ago"

        q_escaped = esc(q)
        trows = ""
        for r in rows:
            role_cls = "badge-medium" if r["role"] == "engineer" else "badge-low"
            trows += (
                f"<tr>"
                f"<td><strong>{esc(r['display_name'])}</strong></td>"
                f"<td>{esc(r['username'])}</td>"
                f"<td><span class='badge {role_cls}'>{esc(r['role'])}</span></td>"
                f"<td>{esc(r['department'] or '—')}</td>"
                f"<td>{fmt_ago(r['last_seen'])}</td>"
                f"</tr>"
            )
        table = (
            f'''<table class="table">
              <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Department</th><th>Last active</th></tr></thead>
              <tbody>{trows}</tbody>
            </table>'''
            if trows else
            f'<p class="empty">{"No results match your search." if q else "No engineers or technicians are currently online."}</p>'
        )
        body = f'''
        <section class="hero card compact-hero">
          <div class="hero-logo-bg"></div>
          <div>
            <p class="eyebrow">Team Presence</p>
            <h1>Engineers &amp; Technicians online</h1>
            <p class="muted">Staff with an active session right now. Sessions expire after {SESSION_IDLE_SECONDS // 60} minutes of inactivity.</p>
          </div>
          <a class="btn" href="/dashboard">Dashboard</a>
        </section>
        <section class="card">
          <form class="cust-search" method="get" action="/online">
            <input type="search" name="q" value="{q_escaped}" placeholder="Search by name, username, or department…">
            <button class="btn btn-small" type="submit">Search</button>
            {"<a class='btn btn-small' href='/online'>Clear</a>" if q else ""}
          </form>
          {table}
        </section>
        '''
        self.send_html(200, render_page("Online Now", body, session=session, warning=self.app_warning()))

    # ── DASHBOARD ─────────────────────────────────────────────────────────────
    # Shows the three metric cards and the full customer list table.
    # To change what metrics appear, edit card_metrics() above and update
    # the metrics-grid section inside this method's body string.
    def dashboard_page(self, session: dict):
        conn = db_conn()
        total, online, open_tickets = card_metrics(conn)
        customers = conn.execute(
            "SELECT id, company_name, status, primary_contact, email, website, updated_at FROM customers ORDER BY updated_at DESC, id DESC"
        ).fetchall()
        conn.close()
        rows = "".join(
            f"<tr><td><a href='/customers/{row['id']}'>{esc(row['company_name'] or '(Untitled customer)')}</a></td>"
            f"<td>{esc(row['status'] or 'Unspecified')}</td>"
            f"<td>{esc(row['primary_contact'] or '—')}</td>"
            f"<td>{esc(row['email'] or '—')}</td>"
            f"<td>{esc(row['website'] or '—')}</td>"
            f"<td>{esc(row['updated_at'])}</td></tr>"
            for row in customers
        )
        if not rows:
            rows = "<tr><td colspan='6' class='empty'>No customers yet. Use <strong>Add Customer</strong> to demonstrate manual entry from an empty system.</td></tr>"
        add_btn = '<a class="btn btn-primary" href="/customers/new">Add Customer</a>' if session.get("role") in ("admin", "engineer") else ""
        body = f'''
        <section class="hero card">
          <div class="hero-logo-bg"></div>
          <div>
            <p class="eyebrow">Customer Operations Workspace</p>
            <h1>Customer operations dashboard</h1>
            <p class="muted">Lamprey runs cleanly with an empty database, supports manual customer entry, and can enrich records from public HTML pages when a source URL is supplied.</p>
          </div>
          {add_btn}
        </section>
        <section class="metrics-grid">
          <article class="metric card"><span>Total customers</span><strong>{total}</strong></article>
          <article class="metric card"><span>Engineers / Technicians online</span><strong><a href="/online" style="color:inherit">{online}</a></strong></article>
          <article class="metric card"><span>Open Tickets</span><strong><a href="/tickets" style="color:inherit">{open_tickets}</a></strong></article>
        </section>
        <section class="card">
          <div class="section-head">
            <div>
              <p class="eyebrow">Customer Records</p>
              <h2>Customer information area</h2>
            </div>
            <p class="muted">Ticketing linkage can be added as an external link field or expanded later to a dedicated ticket API.</p>
          </div>
          <table class="table">
            <thead><tr><th>Customer</th><th>Status</th><th>Primary Contact</th><th>Email</th><th>Website</th><th>Updated</th></tr></thead>
            <tbody>{rows}</tbody>
          </table>
        </section>
        '''
        self.send_html(200, render_page("Dashboard", body, session=session, warning=self.app_warning()))

    # ── CUSTOMER PAGES ────────────────────────────────────────────────────────
    # customers_list_page() — searchable customer list (all roles)
    # customer_form()       — add/edit form (engineer + admin only)
    # save_customer()       — POST handler for customer_form
    # customer_detail()     — full record view with ticket sidebar and audit trail
    # delete_customer_confirm() / delete_customer() — admin-only delete flow
    # enrich_box()          — source-enrichment form widget (reused in form + detail)
    #
    # CUSTOMER FIELDS (stored in the customers table):
    #   company_name, status, customer_type, region, primary_contact,
    #   email, phone, website, notes, address, source_summary, source_url
    #
    # TO ADD A NEW CUSTOMER FIELD:
    #   1. Add an ALTER TABLE migration in init_db() for existing DBs.
    #   2. Add it to the sanitized dict in save_customer().
    #   3. Add it to the UPDATE and INSERT SQL in save_customer().
    #   4. Add the form input in customer_form().
    #   5. Render it in customer_detail() info-grid.
    def customer_form(self, session: dict, customer_id: str | None = None, error: str = ""):
        record = {k: "" for k in ["company_name", "status", "customer_type", "region", "primary_contact", "email", "phone", "website", "notes", "address", "source_summary", "source_url"]}
        heading = "Add Customer"
        action = "/customers/new"
        if customer_id:
            conn = db_conn()
            row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
            conn.close()
            if not row:
                return self.send_error_page(404, "Customer not found.")
            record = dict(row)
            heading = esc(row["company_name"] or "Edit Customer")
            action = f"/customers/{customer_id}/edit"
        body = f'''
        <section class="split-layout">
          <div class="card">
            <div class="section-head">
              <div>
                <p class="eyebrow">Customer Information</p>
                <h1>{heading}</h1>
              </div>
              <a class="btn" href="/customers">Back</a>
            </div>
            {f'<p class="error">{esc(error)}</p>' if error else ''}
            <form method="post" action="{action}" class="stack-form">
              {self.csrf_input(session)}
              <div class="grid-2">
                <label>Company Name<input name="company_name" value="{esc(record.get('company_name') or '')}" placeholder="Acme Manufacturing" maxlength="200"></label>
                <label>Status<input name="status" value="{esc(record.get('status') or '')}" placeholder="Active" maxlength="100"></label>
                <label>Customer Type<input name="customer_type" value="{esc(record.get('customer_type') or '')}" placeholder="Enterprise, SMB, Government, Partner…" maxlength="100"></label>
                <label>Region / DC Location<input name="region" value="{esc(record.get('region') or '')}" placeholder="US-East, EU-West, APAC, DC-NYC…" maxlength="100"></label>
                <label>Primary Contact<input name="primary_contact" value="{esc(record.get('primary_contact') or '')}" placeholder="Jordan Lee" maxlength="200"></label>
                <label>Email<input name="email" type="email" value="{esc(record.get('email') or '')}" placeholder="ops@example.com" maxlength="200"></label>
                <label>Phone<input name="phone" value="{esc(record.get('phone') or '')}" placeholder="555-555-5555" maxlength="100"></label>
                <label>Website<input name="website" value="{esc(record.get('website') or '')}" placeholder="https://example.com" maxlength="300"></label>
              </div>
              <label>Address<textarea name="address" rows="3" maxlength="500" placeholder="123 Main St, City, ST">{esc(record.get('address') or '')}</textarea></label>
              <label>Notes<textarea name="notes" rows="6" maxlength="3000" placeholder="Technician-entered customer context, support notes, or ownership information.">{esc(record.get('notes') or '')}</textarea></label>
              <label>Imported / Source Summary<textarea name="source_summary" rows="6" maxlength="3000" placeholder="This can remain blank for demos and then be enriched later from a source URL.">{esc(record.get('source_summary') or '')}</textarea></label>
              <label>Source URL<input name="source_url" value="{esc(record.get('source_url') or '')}" placeholder="https://customer-site.example" maxlength="300"></label>
              <div class="form-actions">
                <button class="btn btn-primary" type="submit">Save Customer</button>
                <a class="btn" href="/customers">Cancel</a>
              </div>
            </form>
          </div>
          <aside class="card sidebar-card">
            {self.customer_ticket_sidebar(customer_id, session) if customer_id else '<p class="eyebrow">Ticketing Information</p><p class="muted">Save the customer record first to link and create tickets.</p>'}
            {self.enrich_box(customer_id, record, session)}
          </aside>
        </section>
        '''
        self.send_html(200, render_page(heading, body, session=session, warning=self.app_warning()))

    def enrich_box(self, customer_id, record, session):
        if not customer_id:
            return '<div class="enrich-box"><p class="muted">Save the customer first, then enrich from a public website or other reachable HTML source.</p></div>'
        policy = "Private and loopback scrape targets are blocked by default." if not ALLOW_PRIVATE_SCRAPE else "Private scrape targets are currently allowed by configuration."
        return f'''
        <div class="enrich-box">
          <p class="eyebrow">Source Enrichment</p>
          <form method="post" action="/customers/{customer_id}/enrich" class="stack-form">
            {self.csrf_input(session)}
            <label>URL to scrape<input name="source_url" value="{esc(record.get('source_url') or record.get('website') or '')}" placeholder="https://example.com" maxlength="300"></label>
            <button class="btn btn-primary" type="submit">Pull Source Metadata</button>
          </form>
          <p class="muted">Lamprey collects HTML title, meta description, headings, public emails, and public phone patterns only. {esc(policy)}</p>
        </div>
        '''

    def save_customer(self, session: dict, customer_id: str | None = None):
        form = self.require_csrf(session)
        username = session["username"]
        sanitized = {
            "company_name": normalize_text(form.get("company_name", ""), 200),
            "status": normalize_text(form.get("status", ""), 100),
            "customer_type": normalize_text(form.get("customer_type", ""), 100),
            "region": normalize_text(form.get("region", ""), 100),
            "primary_contact": normalize_text(form.get("primary_contact", ""), 200),
            "email": normalize_text(form.get("email", ""), 200),
            "phone": normalize_text(form.get("phone", ""), 100),
            "website": normalize_text(form.get("website", ""), 300),
            "notes": normalize_text(form.get("notes", ""), 3000),
            "address": normalize_text(form.get("address", ""), 500),
            "source_summary": normalize_text(form.get("source_summary", ""), 3000),
            "source_url": normalize_text(form.get("source_url", ""), 300),
        }
        conn = db_conn()
        cur = conn.cursor()
        if customer_id:
            cur.execute(
                """
                UPDATE customers
                SET company_name=?, status=?, customer_type=?, region=?, primary_contact=?, email=?, phone=?, website=?, notes=?, address=?, source_summary=?, source_url=?, updated_by=?, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
                """,
                (
                    sanitized["company_name"], sanitized["status"], sanitized["customer_type"], sanitized["region"],
                    sanitized["primary_contact"], sanitized["email"], sanitized["phone"], sanitized["website"],
                    sanitized["notes"], sanitized["address"], sanitized["source_summary"], sanitized["source_url"],
                    username, customer_id,
                ),
            )
            cur.execute("INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'update_customer', ?, ?)", (username, customer_id, json.dumps(sanitized)))
            target_id = customer_id
        else:
            cur.execute(
                """
                INSERT INTO customers (company_name, status, customer_type, region, primary_contact, email, phone, website, notes, address, source_summary, source_url, created_by, updated_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sanitized["company_name"], sanitized["status"], sanitized["customer_type"], sanitized["region"],
                    sanitized["primary_contact"], sanitized["email"], sanitized["phone"], sanitized["website"],
                    sanitized["notes"], sanitized["address"], sanitized["source_summary"], sanitized["source_url"],
                    username, username,
                ),
            )
            target_id = str(cur.lastrowid)
            cur.execute("INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'create_customer', ?, ?)", (username, target_id, json.dumps(sanitized)))
        conn.commit()
        conn.close()
        return self.send_redirect(f"/customers/{target_id}")

    def enrich_customer(self, session: dict, customer_id: str):
        # ── SOURCE-OF-TRUTH POLICY ─────────────────────────────────────────────
        # Web-scraped / external data is authoritative for the fields it provides.
        # If the scraper returns a value for email, phone, or website, that value
        # overwrites whatever is currently stored — it does NOT defer to local edits.
        # Fields the scraper returns as empty ("") leave the existing value untouched.
        # This matches the behaviour of apply_external_customer_update() used by
        # all other integration syncs.
        form = self.require_csrf(session)
        source_url = normalize_text(form.get("source_url", ""), 300)
        if not source_url:
            raise ValueError("A source URL is required for enrichment.")
        enriched = scrape_source(source_url)
        conn = db_conn()
        existing = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not existing:
            conn.close()
            return self.send_error_page(404, "Customer not found.")
        # External source wins when it has a value; preserve local value otherwise
        fields = {
            "email":          enriched.get("email") or existing["email"] or "",
            "phone":          enriched.get("phone") or existing["phone"] or "",
            "website":        enriched.get("website") or existing["website"] or "",
            "source_summary": enriched.get("source_summary", ""),
            "source_url":     enriched.get("source_url", source_url),
        }
        # Strip empty strings so apply_external_customer_update preserves blanks
        fields = {k: v for k, v in fields.items() if v}
        apply_external_customer_update(conn, customer_id, fields, source_name="web_scrape", actor=session["username"])
        conn.commit()
        conn.close()
        return self.send_redirect(f"/customers/{customer_id}")

    def customer_detail(self, session: dict, customer_id: str):
        params = query_params(self.path)
        conn = db_conn()
        row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
        logs = conn.execute(
            "SELECT actor, action, details, created_at FROM audit_log WHERE customer_id = ? ORDER BY id DESC LIMIT 10", (customer_id,)
        ).fetchall()
        contacts = conn.execute(
            "SELECT id, name, email, phone, title, notes FROM customer_contacts WHERE customer_id=? ORDER BY name ASC",
            (customer_id,)
        ).fetchall()
        conn.close()
        if not row:
            return self.send_error_page(404, "Customer not found.")
        can_manage_contacts = session.get("role") in ("admin", "engineer")
        source_lines = "<br>".join(esc(line) for line in (row["source_summary"] or "").splitlines()) or "No imported data yet."
        audit_rows = "".join(
            f"<tr><td>{esc(log['created_at'])}</td><td>{esc(log['actor'])}</td><td>{esc(log['action'])}</td><td>{esc((log['details'] or '')[:120])}</td></tr>"
            for log in logs
        ) or "<tr><td colspan='4' class='empty'>No audit history yet.</td></tr>"
        def contact_row(c):
            delete_btn = ""
            if can_manage_contacts:
                csrf = session.get("csrf_token", "")
                delete_btn = (
                    f'<form method="post" action="/customers/{customer_id}/contacts/{c["id"]}/delete" '
                    f'style="display:inline" onsubmit="return confirm(\'Remove this contact?\');">'
                    f'<input type="hidden" name="csrf_token" value="{esc(csrf)}">'
                    f'<button class="btn btn-small" type="submit" style="color:var(--error);border-color:rgba(185,28,28,.35);">Remove</button>'
                    f'</form>'
                )
            return (
                f"<tr>"
                f"<td><strong>{esc(c['name'])}</strong></td>"
                f"<td>{esc(c['title'] or '—')}</td>"
                f"<td>{esc(c['email'] or '—')}</td>"
                f"<td>{esc(c['phone'] or '—')}</td>"
                f"<td>{delete_btn}</td>"
                f"</tr>"
            )
        contacts_rows = "".join(contact_row(c) for c in contacts) or "<tr><td colspan='6' class='empty'>No contacts added yet.</td></tr>"
        add_contact_btn = f'<a class="btn btn-primary btn-small" href="/customers/{customer_id}/contacts/new">+ Add Contact</a>' if can_manage_contacts else ""
        body = f'''
        <section class="detail-grid">
          <div class="card">
            <div class="section-head">
              <div>
                <p class="eyebrow">Customer Information</p>
                <h1>{esc(row['company_name'] or '(Untitled customer)')}</h1>
              </div>
              <div class="button-row">
                {'<a class="btn btn-primary" href="/customers/' + customer_id + '/edit">Edit</a>' if session.get("role") in ("admin", "engineer") else ""}
                {'<a class="btn btn-small" href="/customers/' + customer_id + '/delete" style="color:var(--error);border-color:rgba(185,28,28,.35);">Delete</a>' if session.get("role") == "admin" else ""}
                <a class="btn" href="/customers">Customers</a>
              </div>
            </div>
            <div class="info-grid">
              <div><span>Status</span><strong>{esc(row['status'] or 'Unspecified')}</strong></div>
              <div><span>Customer Type</span><strong>{esc(row['customer_type'] or '—')}</strong></div>
              <div><span>Region / DC Location</span><strong>{esc(row['region'] or '—')}</strong></div>
              <div><span>Primary Contact</span><strong>{esc(row['primary_contact'] or '—')}</strong></div>
              <div><span>Email</span><strong>{esc(row['email'] or '—')}</strong></div>
              <div><span>Phone</span><strong>{esc(row['phone'] or '—')}</strong></div>
              <div><span>Website</span><strong>{esc(row['website'] or '—')}</strong></div>
              <div><span>Source URL</span><strong>{esc(row['source_url'] or '—')}</strong></div>
              <div><span>Last External Sync</span><strong>{esc(row['last_synced_at'] or 'Never')}</strong></div>
              <div><span>Sync Source</span><strong>{esc(row['sync_source'] or '—')}</strong></div>
            </div>
            <div class="content-block"><h2>Address</h2><p>{esc(row['address'] or 'No address entered.')}</p></div>
            <div class="content-block"><h2>Technician Notes</h2><p>{esc(row['notes'] or 'No notes entered.')}</p></div>
          </div>
          <aside class="card">
            {self.customer_ticket_sidebar(customer_id, session, params.get("msg", ""))}
            {self.enrich_box(customer_id, dict(row), session)}
          </aside>
        </section>
        <section class="split-layout detail-lower">
          <div class="card">
            <p class="eyebrow">Imported / Scraped Source Data</p>
            <h2>Source summary</h2>
            <p class="source-box">{source_lines}</p>
          </div>
          <div class="card">
            <p class="eyebrow">Audit Trail</p>
            <h2>Recent changes</h2>
            <table class="table compact"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Details</th></tr></thead><tbody>{audit_rows}</tbody></table>
          </div>
        </section>
        <section class="card" style="margin-top:20px;">
          <div class="section-head">
            <div>
              <p class="eyebrow">Organisation Contacts</p>
              <h2>Authorised contacts</h2>
              <p class="muted" style="font-size:.9rem;margin-top:6px;">Named individuals authorised to raise requests on behalf of this organisation. Email addresses receive outbound notifications when a staff member posts a customer-visible ticket note.</p>
            </div>
            {add_contact_btn}
          </div>
          <table class="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Title</th>
                <th>Email</th>
                <th>Phone</th>
                <th></th>
              </tr>
            </thead>
            <tbody>{contacts_rows}</tbody>
          </table>
        </section>
        '''
        self.send_html(200, render_page("Customer Detail", body, session=session, warning=self.app_warning()))

    # ── USER MANAGEMENT PAGES ─────────────────────────────────────────────────
    # users_page()          — list all accounts; visible to engineer + admin
    # user_form()           — add/edit form; engineers see only technician role
    # save_user()           — POST handler; enforces role=technician for engineers
    # delete_user_confirm() — admin-only confirmation page (GET)
    # delete_user()         — admin-only delete POST; preserves audit log rows
    #
    # ROLE HIERARCHY (enforced server-side in save_user):
    #   engineer → may only create technician accounts
    #   admin    → may create/edit/delete any role including other admins
    #
    # PASSWORD RULES:
    #   New users require a password of at least 10 characters.
    #   Editing a user with a blank password field leaves the password unchanged.
    def users_page(self, session: dict):
        params = query_params(self.path)
        is_admin = session.get("role") == "admin"
        is_engineer = session.get("role") == "engineer"
        me = session.get("username", "")
        conn = db_conn()
        users = conn.execute("SELECT id, username, display_name, role, department, is_active, updated_at FROM users ORDER BY username ASC").fetchall()
        conn.close()
        def row_actions(row):
            uid = str(row["id"])
            is_self = row["username"] == me
            parts = []
            if is_admin:
                parts.append(f'<a class="btn btn-small" href="/users/{uid}/edit">Manage</a>')
                if not is_self:
                    parts.append(f'<a class="btn btn-small" href="/users/{uid}/delete" style="color:var(--error);border-color:rgba(185,28,28,.35);">Delete</a>')
            return " ".join(parts) if parts else "—"
        rows = "".join(
            f"<tr><td>{esc(row['username'])}</td><td>{esc(row['display_name'])}</td>"
            f"<td>{esc(row['role'])}</td>"
            f"<td>{esc(row['department'] or '—')}</td>"
            f"<td>{'Active' if int(row['is_active']) == 1 else 'Disabled'}</td>"
            f"<td>{esc(row['updated_at'])}</td>"
            f"<td>{row_actions(row)}</td></tr>"
            for row in users
        )
        add_btn = '<a class="btn btn-primary" href="/users/new">Add User</a>' if (is_admin or is_engineer) else ""
        view_note = "Engineers can add technician accounts. Admins can manage and delete all accounts." if is_engineer else ""
        body = f'''
        <section class="hero card compact-hero">
          <div>
            <p class="eyebrow">User Management</p>
            <h1>Team accounts</h1>
            <p class="muted">Local Lamprey user accounts for this deployment. Roles: admin, engineer, technician.{" " + view_note if view_note else ""}</p>
          </div>
          {add_btn}
        </section>
        <section class="card">
          <div class="section-head">
            <div><p class="eyebrow">Accounts</p><h2>Local app users</h2></div>
          </div>
          <table class="table">
            <thead><tr><th>Username</th><th>Display Name</th><th>Role</th><th>Department</th><th>Status</th><th>Updated</th><th>Action</th></tr></thead>
            <tbody>{rows}</tbody>
          </table>
        </section>
        '''
        self.send_html(200, render_page("Users", body, session=session, message=params.get("msg", ""), warning=self.app_warning()))

    def user_form(self, session: dict, user_id: str | None = None, error: str = ""):
        record = {"username": "", "display_name": "", "role": "technician", "is_active": 1}
        heading = "Add User"
        action = "/users/new"
        password_hint = "Set an initial password for the new user."
        if user_id:
            conn = db_conn()
            row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
            conn.close()
            if not row:
                return self.send_error_page(404, "User not found.")
            record = dict(row)
            heading = f"Manage User: {esc(row['username'])}"
            action = f"/users/{user_id}/edit"
            password_hint = "Leave password blank to keep the current password unchanged."
        caller_is_engineer = session.get("role") == "engineer"
        caller_is_admin = session.get("role") == "admin"
        is_self = record.get("username") == session.get("username")
        role_admin = "selected" if record.get("role") == "admin" else ""
        role_engineer = "selected" if record.get("role") == "engineer" else ""
        role_tech = "selected" if record.get("role") == "technician" or record.get("role") not in ("admin", "engineer") else ""
        active_checked = "checked" if int(record.get("is_active", 1)) == 1 else ""
        disable_status_toggle = "disabled" if is_self else ""
        self_edit_note = "<p class='muted'>Your own account cannot be disabled from this screen.</p>" if is_self else ""
        if caller_is_engineer:
            role_select = '<select name="role"><option value="technician" selected>technician</option></select>'
        else:
            role_select = f'''<select name="role">
                    <option value="technician" {role_tech}>technician</option>
                    <option value="engineer" {role_engineer}>engineer</option>
                    <option value="admin" {role_admin}>admin</option>
                  </select>'''
        # Build department dropdown from the DEPARTMENTS list in the config block.
        # The currently saved value is pre-selected; blank option allows "no dept".
        current_dept = record.get("department") or ""
        dept_options = '<option value="">— No department —</option>'
        for dept in DEPARTMENTS:
            sel = "selected" if dept == current_dept else ""
            dept_options += f'<option value="{esc(dept)}" {sel}>{esc(dept)}</option>'
        delete_btn = ""
        if caller_is_admin and user_id and not is_self:
            delete_btn = f'<a class="btn btn-small" href="/users/{user_id}/delete" style="color:var(--error);border-color:rgba(185,28,28,.35);">Delete User</a>'
        body = f'''
        <section class="split-layout">
          <div class="card">
            <div class="section-head">
              <div>
                <p class="eyebrow">User Management</p>
                <h1>{heading}</h1>
              </div>
              <div class="button-row">
                {delete_btn}
                <a class="btn" href="/users">Back to Users</a>
              </div>
            </div>
            {f'<p class="error">{esc(error)}</p>' if error else ''}
            <form method="post" action="{action}" class="stack-form">
              {self.csrf_input(session)}
              <div class="grid-2">
                <label>Username<input name="username" value="{esc(record.get('username') or '')}" maxlength="64" {'readonly' if user_id else ''} required></label>
                <label>Display Name<input name="display_name" value="{esc(record.get('display_name') or '')}" maxlength="120" required></label>
              </div>
              <div class="grid-2">
                <label>Role {role_select}</label>
                <label>Department<select name="department">{dept_options}</select></label>
              </div>
              <label class="checkbox-line" style="padding-top:8px"><input type="checkbox" name="is_active" value="1" {active_checked} {disable_status_toggle}> Account active</label>
              {self_edit_note}
              <label>Password<input type="password" name="password" maxlength="256" placeholder="{'Create password' if not user_id else 'Leave blank to keep current password'}"></label>
              <p class="muted">{password_hint}</p>
              <div class="form-actions">
                <button class="btn btn-primary" type="submit">Save User</button>
                <a class="btn" href="/users">Cancel</a>
              </div>
            </form>
          </div>
          <aside class="card sidebar-card">
            <p class="eyebrow">Access Model</p>
            <h2>Demo-safe local accounts</h2>
            <div class="ticket-box">
              <div><span>Admins</span><strong>Add, edit, and delete any account or customer</strong></div>
              <div><span>Engineers</span><strong>Add technician accounts and customers</strong></div>
              <div><span>Technicians</span><strong>Read customers, create and comment on tickets</strong></div>
            </div>
          </aside>
        </section>
        '''
        self.send_html(200, render_page(heading, body, session=session, warning=self.app_warning()))

    def save_user(self, session: dict, user_id: str | None = None):
        form = self.require_csrf(session)
        username = normalize_text(form.get("username", "").lower(), 64)
        display_name = normalize_text(form.get("display_name", ""), 120)
        role = normalize_text(form.get("role", "technician"), 32)
        password = form.get("password", "")[:256]
        is_active = 1 if form.get("is_active") == "1" else 0
        # Validate department against the authoritative DEPARTMENTS list.
        # An empty string is allowed (no department assigned).
        department = normalize_text(form.get("department", ""), 120)
        if department and department not in DEPARTMENTS:
            raise ValueError("Invalid department selection.")
        if role not in {"admin", "engineer", "technician"}:
            raise ValueError("Invalid role.")
        if session.get("role") == "engineer":
            role = "technician"  # engineers may only create technician accounts
        if not user_id and not username:
            raise ValueError("Username is required.")
        if not user_id and not re.fullmatch(r"[a-zA-Z0-9_.-]{3,64}", username):
            raise ValueError("Username must be 3-64 characters and contain only letters, numbers, underscore, dot, or hyphen.")
        if not display_name:
            raise ValueError("Display name is required.")
        conn = db_conn()
        cur = conn.cursor()
        if user_id:
            existing = cur.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
            if not existing:
                conn.close()
                return self.send_error_page(404, "User not found.")
            target_username = existing["username"]
            if target_username == session["username"] and is_active == 0:
                conn.close()
                raise ValueError("You cannot disable your own account from this screen.")
            if password:
                salt, pwd_hash = hash_password(password)
                cur.execute(
                    "UPDATE users SET display_name=?, role=?, department=?, is_active=?, password_salt=?, password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (display_name, role, department, is_active, salt, pwd_hash, user_id),
                )
            else:
                cur.execute(
                    "UPDATE users SET display_name=?, role=?, department=?, is_active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    (display_name, role, department, is_active, user_id),
                )
            msg = f"User {target_username} updated."
        else:
            if len(password) < 10:
                conn.close()
                raise ValueError("New users must be created with a password that is at least 10 characters long.")
            exists = cur.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone()
            if exists:
                conn.close()
                raise ValueError("That username already exists.")
            salt, pwd_hash = hash_password(password)
            cur.execute(
                "INSERT INTO users (username, display_name, password_salt, password_hash, role, department, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (username, display_name, salt, pwd_hash, role, department, is_active),
            )
            msg = f"User {username} created."
        conn.commit()
        conn.close()
        return self.send_redirect("/users?msg=" + urllib.parse.quote(msg))

    def delete_user_confirm(self, session: dict, user_id: str):
        conn = db_conn()
        row = conn.execute("SELECT id, username, display_name, role FROM users WHERE id = ?", (user_id,)).fetchone()
        conn.close()
        if not row:
            return self.send_error_page(404, "User not found.")
        if row["username"] == session.get("username"):
            return self.send_error_page(403, "You cannot delete your own account.")
        body = f'''
        <section class="slim">
          <div class="card">
            <p class="eyebrow">User Management</p>
            <h1>Delete user?</h1>
            <p>You are about to permanently delete <strong>{esc(row["display_name"])}</strong>
               (<code>{esc(row["username"])}</code>, role: {esc(row["role"])}).
               Their audit log entries will be retained.</p>
            <p class="warning" style="margin-top:14px;">This action cannot be undone.</p>
            <form method="post" action="/users/{user_id}/delete" class="form-actions" style="margin-top:20px;">
              {self.csrf_input(session)}
              <button class="btn btn-primary" type="submit" style="background:rgba(185,28,28,.15);border-color:rgba(185,28,28,.4);color:var(--error);">Yes, delete this user</button>
              <a class="btn" href="/users">Cancel</a>
            </form>
          </div>
        </section>
        '''
        self.send_html(200, render_page("Delete User", body, session=session, warning=self.app_warning()))

    def delete_user(self, session: dict, user_id: str):
        self.require_csrf(session)
        conn = db_conn()
        row = conn.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            conn.close()
            return self.send_error_page(404, "User not found.")
        if row["username"] == session.get("username"):
            conn.close()
            return self.send_error_page(403, "You cannot delete your own account.")
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.execute(
            "INSERT INTO audit_log (actor, action, details) VALUES (?, 'delete_user', ?)",
            (session["username"], json.dumps({"deleted_username": row["username"]}))
        )
        conn.commit()
        conn.close()
        return self.send_redirect("/users?msg=" + urllib.parse.quote(f"User {row['username']} deleted."))

    def delete_customer_confirm(self, session: dict, customer_id: str):
        conn = db_conn()
        row = conn.execute("SELECT id, company_name FROM customers WHERE id = ?", (customer_id,)).fetchone()
        open_count = conn.execute(
            "SELECT COUNT(*) AS c FROM tickets WHERE customer_id = ? AND status NOT IN ('Resolved','Closed')", (customer_id,)
        ).fetchone()["c"] if row else 0
        conn.close()
        if not row:
            return self.send_error_page(404, "Customer not found.")
        warn_tickets = f'<p class="warning" style="margin-top:14px;"><strong>{open_count} open ticket(s)</strong> are linked to this customer and will also be deleted.</p>' if open_count else ""
        body = f'''
        <section class="slim">
          <div class="card">
            <p class="eyebrow">Customer Management</p>
            <h1>Delete customer?</h1>
            <p>You are about to permanently delete <strong>{esc(row["company_name"])}</strong> and all associated tickets and notes.
               Audit log entries will be retained.</p>
            {warn_tickets}
            <p class="warning" style="margin-top:14px;">This action cannot be undone.</p>
            <form method="post" action="/customers/{customer_id}/delete" class="form-actions" style="margin-top:20px;">
              {self.csrf_input(session)}
              <button class="btn btn-primary" type="submit" style="background:rgba(185,28,28,.15);border-color:rgba(185,28,28,.4);color:var(--error);">Yes, delete this customer</button>
              <a class="btn" href="/customers/{customer_id}">Cancel</a>
            </form>
          </div>
        </section>
        '''
        self.send_html(200, render_page("Delete Customer", body, session=session, warning=self.app_warning()))

    def delete_customer(self, session: dict, customer_id: str):
        self.require_csrf(session)
        conn = db_conn()
        row = conn.execute("SELECT company_name FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not row:
            conn.close()
            return self.send_error_page(404, "Customer not found.")
        ticket_ids = [r["id"] for r in conn.execute("SELECT id FROM tickets WHERE customer_id = ?", (customer_id,)).fetchall()]
        if ticket_ids:
            conn.execute(f"DELETE FROM ticket_notes WHERE ticket_id IN ({','.join('?' for _ in ticket_ids)})", ticket_ids)
            conn.execute(f"DELETE FROM tickets WHERE id IN ({','.join('?' for _ in ticket_ids)})", ticket_ids)
        conn.execute("DELETE FROM customers WHERE id = ?", (customer_id,))
        conn.execute(
            "INSERT INTO audit_log (actor, action, details) VALUES (?, 'delete_customer', ?)",
            (session["username"], json.dumps({"company_name": row["company_name"], "tickets_removed": len(ticket_ids)}))
        )
        conn.commit()
        conn.close()
        return self.send_redirect("/customers?msg=" + urllib.parse.quote(f"Customer '{row['company_name']}' deleted."))

    # ── TICKET NOTE / COMMENT ─────────────────────────────────────────────────
    # add_ticket_note() — POST handler for the comment form on ticket_detail.
    # All roles (including technician) may add notes.
    # Notes are stored in the ticket_notes table linked by ticket_id.
    # Notes are permanent — there is no edit or delete on individual notes.
    # To add note editing: add a GET /tickets/<id>/notes/<note_id>/edit route
    # and a corresponding POST handler with an engineer/admin gate.
    def add_ticket_note(self, session, ticket_id):
        # ── NOTE VISIBILITY + CONTACT NOTIFICATION ────────────────────────────
        # Staff toggle visibility: unchecked = internal, checked = customer visible.
        # When a note is marked customer-visible, notify_customer_contacts() emails
        # all named contacts on the linked customer record (if SMTP is configured).
        # Customer-visible notes serve as the outbound communication record — the
        # contact emails the support address and staff reply via customer-visible notes.
        form = self.require_csrf(session)
        body = normalize_text(form.get("body", ""), 3000)
        if not body:
            raise ValueError("Note body cannot be empty.")
        visibility = "customer" if form.get("visibility") == "customer" else "internal"
        conn = db_conn()
        ticket = conn.execute(
            "SELECT id, customer_id, ticket_number, title FROM tickets WHERE id = ?", (ticket_id,)
        ).fetchone()
        if not ticket:
            conn.close()
            return self.send_error_page(404, "Ticket not found.")
        conn.execute(
            "INSERT INTO ticket_notes (ticket_id, author, body, visibility) VALUES (?, ?, ?, ?)",
            (ticket_id, session["username"], body, visibility),
        )
        conn.execute(
            "INSERT INTO audit_log (actor, action, ticket_id, details) VALUES (?, 'add_ticket_note', ?, ?)",
            (session["username"], ticket_id, json.dumps({"preview": body[:120], "visibility": visibility})),
        )
        if visibility == "customer" and ticket["customer_id"]:
            subject = f"Update on {ticket['ticket_number']}: {ticket['title']}"
            notify_customer_contacts(conn, ticket["customer_id"], subject, body, actor=session["username"])
        conn.commit()
        conn.close()
        msg = "Note posted — contacts notified." if visibility == "customer" else "Note added."
        return self.send_redirect(f"/tickets/{ticket_id}?msg={urllib.parse.quote(msg)}")

    # ── AUDIT LOG PAGE ────────────────────────────────────────────────────────
    # audit_log_page() — searchable view of the audit_log table.
    # Technicians are hard-scoped to only see their own entries (enforced in SQL).
    # Engineers and admins can filter by actor, action, and date range.
    # Results are capped at 200 rows; the table auto-purges entries older than
    # AUDIT_RETENTION_SECONDS (default 90 days) during cleanup_db_state().
    #
    # AUDIT LOG WRITE PATTERN (used throughout the code):
    #   conn.execute(
    #       "INSERT INTO audit_log (actor, action, customer_id, ticket_id, details) VALUES (?, ?, ?, ?, ?)",
    #       (session["username"], "action_name", customer_id, ticket_id, json.dumps({...}))
    #   )
    # actor      — username of the person who performed the action
    # action     — short snake_case label (e.g. "create_ticket", "delete_customer")
    # customer_id / ticket_id — optional FK for filtering by record
    # details    — JSON blob for any additional context (key/value pairs)
    def audit_log_page(self, session):
        params = query_params(self.path)
        is_technician = session.get("role") == "technician"
        actor_filter = session["username"] if is_technician else params.get("actor", "").strip()
        action_filter = params.get("action", "").strip()
        from_filter = params.get("from", "").strip()
        to_filter = params.get("to", "").strip()
        # Build query with safe parameterization
        clauses = ["created_at >= datetime('now', '-90 days')"]
        args = []
        if actor_filter:
            clauses.append("actor = ?")
            args.append(actor_filter)
        if action_filter:
            clauses.append("action = ?")
            args.append(action_filter)
        if from_filter:
            clauses.append("created_at >= ?")
            args.append(from_filter + " 00:00:00")
        if to_filter:
            clauses.append("created_at <= ?")
            args.append(to_filter + " 23:59:59")
        where = " AND ".join(clauses)
        conn = db_conn()
        logs = conn.execute(
            f"SELECT actor, action, customer_id, ticket_id, details, created_at FROM audit_log WHERE {where} ORDER BY created_at DESC LIMIT 200",
            args,
        ).fetchall()
        conn.close()
        rows = "".join(
            f"<tr>"
            f"<td>{esc(log['created_at'])}</td>"
            f"<td>{esc(log['actor'])}</td>"
            f"<td>{esc(log['action'])}</td>"
            f"<td>{'<a href=\"/customers/' + str(log['customer_id']) + '\">#' + str(log['customer_id']) + '</a>' if log['customer_id'] else '—'}</td>"
            f"<td>{'<a href=\"/tickets/' + str(log['ticket_id']) + '\">' + esc(str(log['ticket_id'])) + '</a>' if log['ticket_id'] else '—'}</td>"
            f"<td>{esc((log['details'] or '')[:100])}</td>"
            f"</tr>"
            for log in logs
        ) or "<tr><td colspan='6' class='empty'>No audit entries match the current filters.</td></tr>"
        scope_note = "Showing your activity only." if is_technician else "Showing all user activity. Technicians see only their own entries."
        actor_field = (
            f'<label>Actor<input name="actor" value="{esc(actor_filter)}" placeholder="username" maxlength="64"></label>'
            if not is_technician else ""
        )
        body = f'''
        <section class="hero card compact-hero">
          <div>
            <p class="eyebrow">Audit Log</p>
            <h1>Activity history</h1>
            <p class="muted">Searchable log of all actions for the past 3 months. {esc(scope_note)}</p>
          </div>
        </section>
        <section class="card">
          <form method="get" action="/audit" class="stack-form" style="margin-bottom:18px">
            <div class="grid-2">
              {actor_field}
              <label>Action<input name="action" value="{esc(action_filter)}" placeholder="e.g. create_ticket" maxlength="64"></label>
              <label>From date<input type="date" name="from" value="{esc(from_filter)}"></label>
              <label>To date<input type="date" name="to" value="{esc(to_filter)}"></label>
            </div>
            <div class="form-actions">
              <button class="btn btn-primary" type="submit">Search</button>
              <a class="btn" href="/audit">Clear</a>
            </div>
          </form>
          <table class="table compact">
            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Customer</th><th>Ticket</th><th>Details</th></tr></thead>
            <tbody>{rows}</tbody>
          </table>
        </section>
        '''
        self.send_html(200, render_page("Audit Log", body, session=session, warning=self.app_warning()))

    def customers_list_page(self, session: dict):
        import urllib.parse
        params = query_params(self.path)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0].strip()
        conn = db_conn()
        base_sql = """
            SELECT c.id, c.company_name, c.status, c.customer_type, c.region,
                   COUNT(t.id) AS open_tickets
            FROM customers c
            LEFT JOIN tickets t ON t.customer_id = c.id
                AND t.status NOT IN ('Resolved','Closed')
        """
        if q:
            rows = conn.execute(
                base_sql + """
            WHERE (c.company_name LIKE ? OR c.customer_type LIKE ? OR c.region LIKE ?)
            GROUP BY c.id ORDER BY c.company_name
                """,
                (f"%{q}%", f"%{q}%", f"%{q}%")
            ).fetchall()
        else:
            rows = conn.execute(
                base_sql + " GROUP BY c.id ORDER BY c.company_name"
            ).fetchall()
        conn.close()

        role = session.get("role", "")
        add_btn = ""
        if role in ("admin", "engineer"):
            add_btn = '<a class="btn btn-primary btn-small" href="/customers/new">+ Add Customer</a>'

        q_escaped = esc(q)
        search_form = f'''
        <form class="cust-search" method="get" action="/customers">
          <input type="search" name="q" value="{q_escaped}" placeholder="Search by name, type, or region…">
          <button class="btn btn-small" type="submit">Search</button>
          {"<a class='btn btn-small' href='/customers'>Clear</a>" if q else ""}
        </form>
        '''

        if rows:
            trows = ""
            for r in rows:
                open_count = r["open_tickets"]
                ticket_cls = "chip-tickets chip-warn" if open_count > 0 else "chip-tickets"
                type_chip  = f'<span class="chip chip-neutral">{esc(r["customer_type"] or "—")}</span>' if r["customer_type"] else '<span class="chip chip-neutral">—</span>'
                region_chip = f'<span class="chip chip-neutral">{esc(r["region"] or "—")}</span>' if r["region"] else '<span class="chip chip-neutral">—</span>'
                ticket_chip = f'<span class="chip {ticket_cls}">{open_count} open</span>'
                trows += f'''
                <tr>
                  <td><a href="/customers/{r["id"]}">{esc(r["company_name"])}</a></td>
                  <td><div class="cust-chips">{ticket_chip}</div></td>
                  <td><div class="cust-chips">{region_chip}</div></td>
                  <td><div class="cust-chips">{type_chip}</div></td>
                </tr>'''
            table = f'''
            <table class="table cust-table">
              <thead><tr><th>Customer</th><th>Open Tickets</th><th>Region / DC Location</th><th>Customer Type</th></tr></thead>
              <tbody>{trows}</tbody>
            </table>'''
        else:
            table = f'<p class="empty">{"No customers match your search." if q else "No customers found."}</p>'

        body = f'''
        <section class="hero card compact-hero">
          <div class="hero-logo-bg"></div>
          <div>
            <p class="eyebrow">Customer Operations Workspace</p>
            <h1>Customers</h1>
            <p class="muted">All accounts — search by name, type, or region.</p>
          </div>
          <div>{add_btn}</div>
        </section>
        <section class="card">
          {search_form}
          {table}
        </section>
        '''
        self.send_html(200, render_page("Customers", body, session=session, message=params.get("msg", ""), warning=self.app_warning()))

    # ── CUSTOMER PORTAL ────────────────────────────────────────────────────────
    # ── CUSTOMER CONTACTS ──────────────────────────────────────────────────────
    # Customer contacts are named individuals within a customer organisation.
    # They are authorisation references — confirming who is permitted to raise
    # requests on behalf of that org. They do NOT have Lamprey logins.
    # External customers email support@yourorg.com; inbound emails are converted
    # to tickets by staff. When a staff member posts a customer-visible note,
    # notify_customer_contacts() emails all contacts with an address on file.
    def customer_contact_form(self, session: dict, customer_id: str, error: str = ""):
        conn = db_conn()
        org = conn.execute("SELECT id, company_name FROM customers WHERE id=?", (customer_id,)).fetchone()
        conn.close()
        if not org:
            return self.send_error_page(404, "Customer not found.")
        body = f'''
        <section class="slim">
          <div class="card">
            <div class="section-head">
              <div>
                <p class="eyebrow">{esc(org["company_name"] or "Customer")}</p>
                <h1>Add Contact</h1>
              </div>
              <a class="btn" href="/customers/{customer_id}">Cancel</a>
            </div>
            {f'<p class="error">{esc(error)}</p>' if error else ''}
            <form method="post" action="/customers/{customer_id}/contacts/new" class="stack-form">
              {self.csrf_input(session)}
              <div class="grid-2">
                <label>Full Name<input name="name" required maxlength="200" placeholder="Jordan Lee"></label>
                <label>Title / Role<input name="title" maxlength="120" placeholder="IT Manager"></label>
                <label>Email<input name="email" type="email" maxlength="200" placeholder="jlee@example.com"></label>
                <label>Phone<input name="phone" maxlength="100" placeholder="555-555-5555"></label>
              </div>
              <label>Notes<textarea name="notes" rows="3" maxlength="1000" placeholder="Any context — authorisation scope, preferred contact hours, escalation path…"></textarea></label>
              <div class="form-actions">
                <button class="btn btn-primary" type="submit">Save Contact</button>
              </div>
            </form>
          </div>
        </section>
        '''
        self.send_html(200, render_page("Add Contact", body, session=session, warning=self.app_warning()))

    def save_customer_contact(self, session: dict, customer_id: str):
        form = self.require_csrf(session)
        name = normalize_text(form.get("name", ""), 200)
        title = normalize_text(form.get("title", ""), 120)
        email = normalize_text(form.get("email", ""), 200)
        phone = normalize_text(form.get("phone", ""), 100)
        notes = normalize_text(form.get("notes", ""), 1000)
        if not name:
            raise ValueError("Contact name is required.")
        conn = db_conn()
        if not conn.execute("SELECT id FROM customers WHERE id=?", (customer_id,)).fetchone():
            conn.close()
            return self.send_error_page(404, "Customer not found.")
        conn.execute(
            "INSERT INTO customer_contacts (customer_id, name, email, phone, title, notes, created_by) VALUES (?,?,?,?,?,?,?)",
            (customer_id, name, email, phone, title, notes, session["username"]),
        )
        conn.execute(
            "INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'add_contact', ?, ?)",
            (session["username"], customer_id, json.dumps({"name": name, "email": email})),
        )
        conn.commit()
        conn.close()
        return self.send_redirect(f"/customers/{customer_id}?msg={urllib.parse.quote(name + ' added as a contact.')}")

    def delete_customer_contact(self, session: dict, customer_id: str, contact_id: str):
        self.require_csrf(session)
        conn = db_conn()
        row = conn.execute("SELECT name FROM customer_contacts WHERE id=? AND customer_id=?", (contact_id, customer_id)).fetchone()
        if not row:
            conn.close()
            return self.send_error_page(404, "Contact not found.")
        conn.execute("DELETE FROM customer_contacts WHERE id=?", (contact_id,))
        conn.execute(
            "INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'delete_contact', ?, ?)",
            (session["username"], customer_id, json.dumps({"name": row["name"]})),
        )
        conn.commit()
        conn.close()
        return self.send_redirect(f"/customers/{customer_id}?msg={urllib.parse.quote(row['name'] + ' removed.')}")

    def customer_ticket_sidebar(self, customer_id, session, flash_msg=""):
        conn = db_conn()
        tickets = conn.execute(
            "SELECT id, ticket_number, title, status, priority FROM tickets WHERE customer_id=? ORDER BY updated_at DESC, id DESC LIMIT 5",
            (customer_id,)
        ).fetchall()
        open_count = conn.execute(
            "SELECT COUNT(*) AS c FROM tickets WHERE customer_id=? AND status NOT IN ('Resolved','Closed')",
            (customer_id,)
        ).fetchone()["c"]
        conn.close()
        linked = []
        if ZENDESK_SUBDOMAIN:
            linked.append("ZenDesk")
        if ARTIFACTORY_URL:
            linked.append("Artifactory")
        linked_label = " + ".join(linked) if linked else "Demo mode"
        ticket_rows = ""
        for t in tickets:
            ticket_rows += (
                f'<div><span><a href="/tickets/{t["id"]}">{esc(t["ticket_number"])}</a>'
                f' — {esc((t["title"] or "")[:40])}</span><strong>{esc(t["status"])}</strong></div>'
            )
        if not ticket_rows:
            ticket_rows = '<div><span class="muted">No tickets linked yet.</span></div>'
        flash_html = f'<p class="flash" style="margin-top:8px;font-size:.88rem">{esc(flash_msg)}</p>' if flash_msg else ""
        sync_form = (
            f'<form method="post" action="/customers/{customer_id}/sync_tickets" style="display:inline">'
            f'{self.csrf_input(session)}'
            f'<button class="btn btn-small" type="submit">Sync External</button></form>'
        )
        return (
            f'<p class="eyebrow">Ticketing Information</p>'
            f'<h2>Open Tickets ({open_count})</h2>'
            f'<div class="ticket-box">'
            f'<div><span>Linked system</span><strong>{esc(linked_label)}</strong></div>'
            f'<div><span>Open</span><strong>{open_count}</strong></div>'
            f'</div>'
            f'<div class="ticket-box" style="margin-top:8px">{ticket_rows}</div>'
            f'{flash_html}'
            f'<div class="button-row" style="margin-top:12px">'
            f'<a class="btn btn-primary btn-small" href="/tickets/new?customer_id={customer_id}">New Ticket</a>'
            f'{sync_form}'
            f'</div>'
        )

    # ── TICKET PAGES ──────────────────────────────────────────────────────────
    # tickets_page()    — filterable list of all tickets (all roles)
    # ticket_form()     — create/edit form; all roles can create, engineer+ to edit
    # ticket_detail()   — full ticket view with notes thread and status history
    # save_ticket()     — POST handler; assigns ticket_number on create
    # close_ticket()    — POST handler; engineer+ can set status to Closed
    # add_ticket_note() — POST handler; all roles may comment
    # sync_tickets_for_customer() — pulls ZenDesk + Artifactory tickets and
    #                               upserts them as internal ticket rows
    #
    # TICKET NUMBER FORMAT:  TKT-NNNN  (zero-padded integer, assigned at insert)
    # TICKET STATUSES:  Open | In Progress | Resolved | Closed
    # TICKET PRIORITIES: Critical | High | Medium | Low
    # TICKET SOURCES:   manual | zendesk | artifactory
    #
    # TO ADD A NEW TICKET SOURCE (e.g. a new integration):
    #   1. Add a fetch_<source>() function in the integrations section above.
    #   2. Call it inside sync_tickets_for_customer() and merge results into
    #      the existing upsert loop.
    #   3. Add the new source label to the "source" badge/display in ticket_detail.
    def tickets_page(self, session):
        params = query_params(self.path)
        conn = db_conn()
        tickets = conn.execute(
            """SELECT t.id, t.ticket_number, t.title, t.status, t.priority, t.source,
                      t.assigned_to, t.updated_at, c.company_name
               FROM tickets t
               LEFT JOIN customers c ON t.customer_id = c.id
               ORDER BY
                 CASE t.status WHEN 'Open' THEN 1 WHEN 'In Progress' THEN 2
                               WHEN 'Resolved' THEN 3 ELSE 4 END,
                 t.updated_at DESC"""
        ).fetchall()
        conn.close()
        rows = "".join(
            f"<tr>"
            f"<td><a href='/tickets/{t['id']}'>{esc(t['ticket_number'])}</a></td>"
            f"<td>{esc((t['title'] or '')[:60])}</td>"
            f"<td>{status_badge(t['status'])}</td>"
            f"<td>{priority_badge(t['priority'])}</td>"
            f"<td>{esc(t['company_name'] or '—')}</td>"
            f"<td>{esc(t['assigned_to'] or '—')}</td>"
            f"<td>{esc(t['source'])}</td>"
            f"<td>{esc(t['updated_at'])}</td>"
            f"</tr>"
            for t in tickets
        ) or "<tr><td colspan='8' class='empty'>No tickets yet. Use <strong>New Ticket</strong> to create one, or sync from a customer record.</td></tr>"
        integration_note = (
            "Connected: " + ", ".join(filter(None, [ZENDESK_SUBDOMAIN and f"ZenDesk ({ZENDESK_SUBDOMAIN})", ARTIFACTORY_URL and "Artifactory"]))
            if ZENDESK_SUBDOMAIN or ARTIFACTORY_URL
            else "Demo mode — no external integrations configured. All ticket creation is manual."
        )
        total = len(tickets)
        n_open = sum(1 for t in tickets if t["status"] == "Open")
        n_prog = sum(1 for t in tickets if t["status"] == "In Progress")
        n_done = sum(1 for t in tickets if t["status"] in ("Resolved", "Closed"))
        body = f'''
        <section class="hero card">
          <div>
            <p class="eyebrow">Ticketing</p>
            <h1>Open Tickets</h1>
            <p class="muted">{esc(integration_note)}</p>
          </div>
          <a class="btn btn-primary" href="/tickets/new">New Ticket</a>
        </section>
        <section class="metrics-grid">
          <article class="metric card"><span>Total tickets</span><strong>{total}</strong></article>
          <article class="metric card"><span>Open</span><strong>{n_open}</strong></article>
          <article class="metric card"><span>In Progress</span><strong>{n_prog}</strong></article>
        </section>
        <section class="card">
          <div class="section-head">
            <div><p class="eyebrow">Ticket Queue</p><h2>All tickets</h2></div>
            <p class="muted">{n_done} resolved or closed</p>
          </div>
          <table class="table">
            <thead><tr><th>#</th><th>Title</th><th>Status</th><th>Priority</th><th>Customer</th><th>Assigned</th><th>Source</th><th>Updated</th></tr></thead>
            <tbody>{rows}</tbody>
          </table>
        </section>
        '''
        self.send_html(200, render_page("Tickets", body, session=session, message=params.get("msg", ""), warning=self.app_warning()))

    def ticket_form(self, session, ticket_id=None, error=""):
        params = query_params(self.path)
        conn = db_conn()
        customers = conn.execute("SELECT id, company_name FROM customers ORDER BY company_name ASC").fetchall()
        users = conn.execute("SELECT username, display_name FROM users WHERE is_active=1 ORDER BY username ASC").fetchall()
        record = {"title": "", "description": "", "status": "Open", "priority": "Medium",
                  "customer_id": params.get("customer_id", ""), "assigned_to": "", "external_id": ""}
        heading = "New Ticket"
        action = "/tickets/new"
        if ticket_id:
            row = conn.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
            if not row:
                conn.close()
                return self.send_error_page(404, "Ticket not found.")
            record = dict(row)
            heading = f"Edit Ticket: {esc(row['ticket_number'])}"
            action = f"/tickets/{ticket_id}/edit"
        conn.close()
        def cust_opts():
            o = '<option value="">— No customer linked —</option>'
            for c in customers:
                sel = "selected" if str(c["id"]) == str(record.get("customer_id") or "") else ""
                o += f'<option value="{c["id"]}" {sel}>{esc(c["company_name"] or "(Untitled)")}</option>'
            return o
        def user_opts():
            o = '<option value="">— Unassigned —</option>'
            for u in users:
                sel = "selected" if u["username"] == (record.get("assigned_to") or "") else ""
                o += f'<option value="{esc(u["username"])}" {sel}>{esc(u["display_name"])} ({esc(u["username"])})</option>'
            return o
        def sel_opts(choices, current):
            return "".join(f'<option value="{c}" {"selected" if c == current else ""}>{c}</option>' for c in choices)
        zd_status = "Connected" if ZENDESK_SUBDOMAIN else "Not configured"
        af_status = "Connected" if ARTIFACTORY_URL else "Not configured"
        body = f'''
        <section class="split-layout">
          <div class="card">
            <div class="section-head">
              <div><p class="eyebrow">Ticketing</p><h1>{heading}</h1></div>
              <a class="btn" href="/tickets">Back to Tickets</a>
            </div>
            {f'<p class="error">{esc(error)}</p>' if error else ''}
            <form method="post" action="{action}" class="stack-form">
              {self.csrf_input(session)}
              <label>Title<input name="title" value="{esc(record.get('title') or '')}" required maxlength="200" placeholder="Brief description of the issue"></label>
              <label>Description<textarea name="description" rows="6" maxlength="3000" placeholder="Full details, steps to reproduce, environment info...">{esc(record.get('description') or '')}</textarea></label>
              <div class="grid-2">
                <label>Status<select name="status">{sel_opts(["Open","In Progress","Resolved","Closed"], record.get("status","Open"))}</select></label>
                <label>Priority<select name="priority">{sel_opts(["Low","Medium","High","Critical"], record.get("priority","Medium"))}</select></label>
                <label>Customer<select name="customer_id">{cust_opts()}</select></label>
                <label>Assigned To<select name="assigned_to">{user_opts()}</select></label>
              </div>
              <div class="form-actions">
                <button class="btn btn-primary" type="submit">Save Ticket</button>
                <a class="btn" href="/tickets">Cancel</a>
              </div>
            </form>
          </div>
          <aside class="card sidebar-card">
            <p class="eyebrow">Ticket System</p>
            <h2>Source integrations</h2>
            <div class="ticket-box">
              <div><span>ZenDesk</span><strong>{zd_status}</strong></div>
              <div><span>Artifactory</span><strong>{af_status}</strong></div>
              <div><span>Manual tickets</span><strong>Always available</strong></div>
            </div>
            <p class="muted" style="margin-top:12px">Tickets created here are stored in the local database. Use the Sync External button on a customer record to pull in tickets from connected external sources.</p>
          </aside>
        </section>
        '''
        self.send_html(200, render_page(heading, body, session=session, warning=self.app_warning()))

    def ticket_detail(self, session, ticket_id):
        params = query_params(self.path)
        conn = db_conn()
        row = conn.execute(
            "SELECT t.*, c.company_name FROM tickets t LEFT JOIN customers c ON t.customer_id = c.id WHERE t.id = ?",
            (ticket_id,)
        ).fetchone()
        if not row:
            conn.close()
            return self.send_error_page(404, "Ticket not found.")
        notes = conn.execute(
            "SELECT id, author, body, visibility, created_at FROM ticket_notes WHERE ticket_id=? ORDER BY created_at ASC",
            (ticket_id,)
        ).fetchall()
        conn.close()

        can_manage = session.get("role") in ("admin", "engineer")
        customer_link = (
            f"<a href='/customers/{row['customer_id']}'>{esc(row['company_name'] or '(Untitled)')}</a>"
            if row["customer_id"] else esc(row["company_name"] or "—")
        )
        edit_btn = f'<a class="btn btn-primary" href="/tickets/{ticket_id}/edit">Edit</a>' if can_manage else ""
        close_form = ""
        if can_manage and row["status"] not in ("Resolved", "Closed"):
            close_form = (
                f'<form method="post" action="/tickets/{ticket_id}/close" style="display:inline">'
                f'{self.csrf_input(session)}'
                f'<button class="btn btn-small" type="submit">Close Ticket</button></form>'
            )

        def note_badge(vis):
            if vis == "customer":
                return '<span class="badge badge-resolved" style="font-size:.72rem;margin-left:6px">Customer visible</span>'
            return '<span class="badge badge-closed" style="font-size:.72rem;margin-left:6px">Internal</span>'

        note_items = "".join(
            f'<div class="note-item">'
            f'<div class="note-meta"><strong>{esc(n["author"])}</strong>'
            f'{note_badge(n["visibility"])}'
            f'<span class="muted">{esc(n["created_at"])}</span></div>'
            f'<p class="note-body">{esc(n["body"])}</p></div>'
            for n in notes
        ) or '<p class="muted">No notes yet.</p>'

        visibility_input = f'''
              <label style="flex-direction:row;align-items:center;gap:10px;padding-top:4px">
                <input type="checkbox" name="visibility" value="customer">
                <span>Customer visible — notify contacts by email</span>
              </label>'''

        body = f'''
        <section class="detail-grid">
          <div class="card">
            <div class="section-head">
              <div>
                <p class="eyebrow">Ticket {esc(row["ticket_number"])}</p>
                <h1>{esc(row["title"])}</h1>
              </div>
              <div class="button-row">
                {edit_btn}
                {close_form}
                <a class="btn" href="/tickets">All Tickets</a>
              </div>
            </div>
            <div class="info-grid">
              <div><span>Status</span><strong>{status_badge(row["status"])}</strong></div>
              <div><span>Priority</span><strong>{priority_badge(row["priority"])}</strong></div>
              <div><span>Organisation</span><strong>{customer_link}</strong></div>
              <div><span>Assigned To</span><strong>{esc(row["assigned_to"] or "—")}</strong></div>
              <div><span>Source</span><strong>{esc(row["source"])}</strong></div>
              <div><span>External ID</span><strong>{esc(row["external_id"] or "—")}</strong></div>
              <div><span>Created by</span><strong>{esc(row["created_by"])}</strong></div>
              <div><span>Last updated</span><strong>{esc(row["updated_at"])}</strong></div>
            </div>
            <div class="content-block">
              <h2>Description</h2>
              <p>{esc(row["description"] or "No description provided.")}</p>
            </div>
            <div class="content-block">
              <h2>Activity &amp; Notes</h2>
              <div class="notes-thread">{note_items}</div>
              <form method="post" action="/tickets/{ticket_id}/comment" class="stack-form" style="margin-top:16px">
                {self.csrf_input(session)}
                <label>Add a note<textarea name="body" rows="4" maxlength="3000" placeholder="Update, resolution step, or internal note…"></textarea></label>
                {visibility_input}
                <div class="form-actions">
                  <button class="btn btn-primary" type="submit">Post Note</button>
                </div>
              </form>
            </div>
          </div>
          <aside class="card sidebar-card">
            <p class="eyebrow">Ticket Details</p>
            <h2>{esc(row["ticket_number"])}</h2>
            <div class="ticket-box">
              <div><span>Status</span><strong>{status_badge(row["status"])}</strong></div>
              <div><span>Priority</span><strong>{priority_badge(row["priority"])}</strong></div>
              <div><span>Source</span><strong>{esc(row["source"])}</strong></div>
              <div><span>Created</span><strong>{esc(row["created_at"])}</strong></div>
              <div><span>Notes</span><strong>{len(notes)}</strong></div>
            </div>
          </aside>
        </section>
        '''
        self.send_html(200, render_page(f"Ticket {row['ticket_number']}", body, session=session, message=params.get("msg", ""), warning=self.app_warning()))

    def save_ticket(self, session, ticket_id=None):
        form = self.require_csrf(session)
        title = normalize_text(form.get("title", ""), 200)
        description = normalize_text(form.get("description", ""), 3000)
        status = normalize_text(form.get("status", "Open"), 50)
        priority = normalize_text(form.get("priority", "Medium"), 50)
        raw_cid = normalize_text(form.get("customer_id", ""), 20)
        customer_id = int(raw_cid) if raw_cid.isdigit() else None
        assigned_to = normalize_text(form.get("assigned_to", ""), 64) or None
        if status not in {"Open", "In Progress", "Resolved", "Closed"}:
            raise ValueError("Invalid ticket status.")
        if priority not in {"Low", "Medium", "High", "Critical"}:
            raise ValueError("Invalid ticket priority.")
        if not title:
            raise ValueError("Ticket title is required.")
        conn = db_conn()
        cur = conn.cursor()
        if ticket_id:
            existing = cur.execute("SELECT id FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
            if not existing:
                conn.close()
                return self.send_error_page(404, "Ticket not found.")
            cur.execute(
                "UPDATE tickets SET title=?, description=?, status=?, priority=?, customer_id=?, assigned_to=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (title, description, status, priority, customer_id, assigned_to, session["username"], ticket_id),
            )
            cur.execute(
                "INSERT INTO audit_log (actor, action, ticket_id, details) VALUES (?, 'update_ticket', ?, ?)",
                (session["username"], ticket_id, json.dumps({"title": title, "status": status, "priority": priority})),
            )
            target_id = ticket_id
        else:
            tmp = f"TMP-{secrets.token_hex(6)}"
            cur.execute(
                "INSERT INTO tickets (ticket_number, customer_id, title, description, status, priority, assigned_to, source, created_by, updated_by) VALUES (?,?,?,?,?,?,?,'manual',?,?)",
                (tmp, customer_id, title, description, status, priority, assigned_to, session["username"], session["username"]),
            )
            new_id = cur.lastrowid
            cur.execute("UPDATE tickets SET ticket_number=? WHERE id=?", (f"TKT-{new_id:04d}", new_id))
            cur.execute(
                "INSERT INTO audit_log (actor, action, ticket_id, details) VALUES (?, 'create_ticket', ?, ?)",
                (session["username"], new_id, json.dumps({"title": title, "status": status, "priority": priority})),
            )
            target_id = str(new_id)
        conn.commit()
        conn.close()
        return self.send_redirect(f"/tickets/{target_id}")

    def close_ticket(self, session, ticket_id):
        self.require_csrf(session)
        conn = db_conn()
        existing = conn.execute("SELECT id FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
        if not existing:
            conn.close()
            return self.send_error_page(404, "Ticket not found.")
        conn.execute(
            "UPDATE tickets SET status='Closed', updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (session["username"], ticket_id),
        )
        conn.execute(
            "INSERT INTO audit_log (actor, action, ticket_id, details) VALUES (?, 'close_ticket', ?, ?)",
            (session["username"], ticket_id, json.dumps({"status": "Closed"})),
        )
        conn.commit()
        conn.close()
        return self.send_redirect("/tickets?msg=" + urllib.parse.quote("Ticket closed."))

    def sync_tickets_for_customer(self, session, customer_id):
        # ── SOURCE-OF-TRUTH SYNC ───────────────────────────────────────────────
        # Uses upsert_external_ticket() for every ticket returned by each source.
        # Existing tickets (matched by external_id + source) are UPDATED with the
        # latest title/status/priority from the external system — not skipped.
        # New tickets are created. Both operations are logged to audit_log.
        # The customer record's last_synced_at and sync_source are updated so the
        # UI can show when the last authoritative sync occurred.
        #
        # TO ADD A NEW SYNC SOURCE:
        #   1. Add a fetch_<source>() function in the integrations section above.
        #   2. Call it here and pass each result to upsert_external_ticket().
        #   3. Set source_name in the apply_external_customer_update() call below
        #      if the integration also updates customer fields.
        self.require_csrf(session)
        conn = db_conn()
        customer = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not customer:
            conn.close()
            return self.send_error_page(404, "Customer not found.")

        actor = session["username"]
        created = updated = 0
        sources_hit = []

        # ── ZENDESK ───────────────────────────────────────────────────────────
        zendesk_tickets = fetch_zendesk_tickets(customer["email"] or "")
        for t in zendesk_tickets:
            result = upsert_external_ticket(conn, customer_id, t, actor)
            if result == "created":
                created += 1
            else:
                updated += 1
        if zendesk_tickets:
            sources_hit.append("zendesk")

        # ── ARTIFACTORY ───────────────────────────────────────────────────────
        artifactory_issues = fetch_artifactory_issues(str(customer_id))
        for t in artifactory_issues:
            result = upsert_external_ticket(conn, customer_id, t, actor)
            if result == "created":
                created += 1
            else:
                updated += 1
        if artifactory_issues:
            sources_hit.append("artifactory")

        # ── UPDATE CUSTOMER SYNC STAMP ─────────────────────────────────────────
        # Record which source(s) touched this customer and when, even if no
        # ticket changes were made — the sync itself is worth auditing.
        if sources_hit:
            sync_source = "+".join(sources_hit)
            conn.execute(
                "UPDATE customers SET last_synced_at=CURRENT_TIMESTAMP, sync_source=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (sync_source, actor, customer_id),
            )
            conn.execute(
                "INSERT INTO audit_log (actor, action, customer_id, details) VALUES (?, 'external_sync', ?, ?)",
                (actor, customer_id, json.dumps({"sources": sources_hit, "created": created, "updated": updated})),
            )

        conn.commit()
        conn.close()

        if not ZENDESK_SUBDOMAIN and not ARTIFACTORY_URL:
            msg = "Demo mode: no external integrations configured. Create tickets manually."
        elif created or updated:
            parts = []
            if created:
                parts.append(f"{created} created")
            if updated:
                parts.append(f"{updated} updated")
            msg = f"Sync complete — {', '.join(parts)}."
        else:
            msg = "Sync complete — all tickets already up to date."
        return self.send_redirect(f"/customers/{customer_id}?msg={urllib.parse.quote(msg)}")

    def server_error(self, exc: Exception):
        self.send_html(500, render_page("Server Error", f"<section class='card slim'><h1>Server error</h1><p>{esc(str(exc))}</p></section>"))


# =============================================================================
# SERVER ENTRY POINT
# =============================================================================
# SERVER ENTRY POINT
# =============================================================================
# main() is called when the file is executed directly (python3 app.py) and by
# service managers (systemd, launchd) via the ExecStart line in the unit file.
#
# Service-safe design:
#   - Logs to stdout/stderr (captured by journald / launchd / Docker)
#   - Handles SIGTERM and SIGINT cleanly (drains in-flight requests, stops exporter)
#   - The log exporter runs as a daemon thread — it is stopped before the server
#     socket closes so no audit rows are lost on clean shutdown
#
# TO RUN WITH CUSTOM SETTINGS:
#   APP_HOST=0.0.0.0 APP_PORT=9000 DEFAULT_ADMIN_PASSWORD=securepass python3 app.py
#   Or place vars in scripts/lamprey.env and use the systemd service.
#
# TO RUN BEHIND A REVERSE PROXY (nginx, caddy, traefik):
#   - Set COOKIE_SECURE=1 so cookies carry the Secure flag
#   - Bind to 127.0.0.1 (default) and proxy_pass from the front-end server
#   - Set APP_SECRET to a strong random value (not the derived fallback)
# =============================================================================
def main():
    init_db()

    # ── Start log exporter background thread ──────────────────────────────────
    # The stop_event is set during shutdown so the thread exits cleanly.
    # daemon=True means Python will not wait for it if main() returns unexpectedly.
    stop_event = threading.Event()
    if LOG_EXPORT_URL or LOG_EXPORT_SYSLOG_HOST:
        exporter = threading.Thread(
            target=log_exporter_worker,
            args=(stop_event,),
            name="log-exporter",
            daemon=True,
        )
        exporter.start()
    else:
        exporter = None
        log.info("log_exporter: disabled (set LOG_EXPORT_URL or LOG_EXPORT_SYSLOG_HOST to enable)")

    # ── HTTP server ────────────────────────────────────────────────────────────
    server = ThreadingHTTPServer((HOST, PORT), AppHandler)
    log.info("Lamprey listening on http://%s:%s", HOST, PORT)

    # ── Signal handlers for clean shutdown (SIGTERM from systemd, SIGINT from Ctrl-C)
    def _shutdown(signum, frame):
        sig_name = signal.Signals(signum).name
        log.info("Received %s — shutting down Lamprey", sig_name)
        # Stop the exporter first so the final batch can flush
        stop_event.set()
        if exporter and exporter.is_alive():
            exporter.join(timeout=15)
        server.shutdown()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        server.serve_forever()
    finally:
        stop_event.set()
        log.info("Lamprey stopped")


if __name__ == "__main__":
    main()
